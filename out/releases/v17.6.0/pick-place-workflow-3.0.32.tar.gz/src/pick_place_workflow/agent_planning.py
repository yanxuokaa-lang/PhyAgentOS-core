"""Agent-composed semantic planning projection for the pick-place Skill.

The legacy ``LongHorizonWorkflow`` remains the deterministic baseline/replay
projection.  This module adds the task-level seam: the Agent supplies semantic
subtasks, the planning library builds a concrete DAG, and the Agent may choose
among Tool candidates.  Nothing here invokes a Tool, persists a task, leases a
robot, or authorizes motion.
"""

from __future__ import annotations

import inspect
import re
from typing import Any, Literal, Protocol

from PhyAgentOS.planning import (
    AdmissionContext,
    AdmissionDecision,
    PlanGraph,
    PlanNode,
    ResourceClaim,
    ToolCallEnvelope,
    ToolSpecPolicy,
    admit_tool_call,
    plan_graph_digest,
    validate_graph,
)
from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .subtask_executor import SubtaskOperation, SubtaskSpec

AGENT_PLAN_VERSION = "pick_and_place_agent_plan_v1"
PlanningMode = Literal["baseline", "agent_composed"]
_SAFE_ID = re.compile(r"^[A-Za-z0-9_.:-]+$")
_ENTITY_REF = re.compile(r"^entity://\S+$")


class AgentPlanningError(ValueError):
    """Raised when an Agent-composed semantic plan is invalid."""


class ToolSelectionError(AgentPlanningError):
    """Raised when no frozen ToolSpec candidate matches a semantic capability."""


class SemanticBindingPort(Protocol):
    """Provider-neutral measured-binding port used before plan compilation."""

    @property
    def ready(self) -> bool: ...

    def bind(self) -> Any: ...

    def bind_async(self) -> Any: ...


def bind_subtask_from_semantics(
    subtask_id: str,
    operation: SubtaskOperation,
    perception: SemanticBindingPort,
    *,
    depends_on: tuple[str, ...] = (),
    parameters: dict[str, object] | None = None,
    semantic_intent: dict[str, object] | None = None,
    return_destination_ref: str | None = None,
) -> SubtaskSpec:
    """Bind one semantic obligation through the configured PAOS Query ports.

    This is a planning composition helper only: it performs read-only Query
    calls through the generic perception adapter and returns a SubtaskSpec.
    Task creation, plan persistence, Tool invocation, and settlement remain
    owned by the existing Coordinator and AgentLoop.
    """

    if not callable(getattr(perception, "bind", None)) or perception.ready is not True:
        raise AgentPlanningError("subtask perception adapter is unavailable")
    try:
        binding = perception.bind()
        return SubtaskSpec(
            subtask_id=subtask_id,
            operation=operation,
            binding=binding,
            depends_on=depends_on,
            parameters=parameters or {},
            semantic_intent=semantic_intent,
            return_destination_ref=return_destination_ref,
        )
    except (TypeError, ValueError) as exc:
        raise AgentPlanningError(f"semantic subtask binding failed: {exc}") from exc


async def bind_subtask_from_semantics_async(
    subtask_id: str,
    operation: SubtaskOperation,
    perception: SemanticBindingPort,
    *,
    depends_on: tuple[str, ...] = (),
    parameters: dict[str, object] | None = None,
    semantic_intent: dict[str, object] | None = None,
    return_destination_ref: str | None = None,
) -> SubtaskSpec:
    """Async counterpart for AgentLoop/Gateway Query transports."""
    if not callable(getattr(perception, "bind_async", None)) or perception.ready is not True:
        raise AgentPlanningError("async subtask perception adapter is unavailable")
    try:
        binding = perception.bind_async()
        if inspect.isawaitable(binding):
            binding = await binding
        return SubtaskSpec(
            subtask_id=subtask_id,
            operation=operation,
            binding=binding,
            depends_on=depends_on,
            parameters=parameters or {},
            semantic_intent=semantic_intent,
            return_destination_ref=return_destination_ref,
        )
    except (TypeError, ValueError) as exc:
        raise AgentPlanningError(f"async semantic subtask binding failed: {exc}") from exc


class AgentSubtaskSpec(BaseModel):
    """One semantic obligation supplied by the Agent/task decomposer."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    subtask_id: str
    entity_ref: str
    destination_ref: str | None = Field(default=None, min_length=1)
    goal_relation: str | None = None
    relation_target_ref: str | None = None
    capability: str = "object.relocate"
    depends_on: tuple[str, ...] = ()
    required_evidence: tuple[str, ...] = ()
    produced_evidence: tuple[str, ...] = ()
    resources: tuple[ResourceClaim, ...] = ()
    context_bindings: tuple[tuple[str, str], ...] = ()

    @field_validator("subtask_id", "capability")
    @classmethod
    def safe_identity(cls, value: str) -> str:
        if not isinstance(value, str) or _SAFE_ID.fullmatch(value) is None:
            raise ValueError("subtask_id and capability must be path-safe identifiers")
        return value

    @field_validator("entity_ref")
    @classmethod
    def entity_identity(cls, value: str) -> str:
        if not isinstance(value, str) or _ENTITY_REF.fullmatch(value) is None:
            raise ValueError("entity_ref must be an entity:// reference")
        return value

    @field_validator("goal_relation")
    @classmethod
    def relation_identity(cls, value: str | None) -> str | None:
        if value is not None and _SAFE_ID.fullmatch(value) is None:
            raise ValueError("goal_relation must be a path-safe identifier")
        return value

    @field_validator("relation_target_ref")
    @classmethod
    def relation_target_identity(cls, value: str | None) -> str | None:
        if value is not None and ("://" not in value or value.startswith("://")):
            raise ValueError("relation_target_ref must be an opaque URI reference")
        return value

    @field_validator("depends_on", "required_evidence", "produced_evidence")
    @classmethod
    def unique_values(cls, value: tuple[str, ...]) -> tuple[str, ...]:
        if any(not item.strip() for item in value):
            raise ValueError("subtask values must be non-empty")
        if len(value) != len(set(value)):
            raise ValueError("subtask values must be unique")
        return value

    @field_validator("context_bindings")
    @classmethod
    def unique_context_keys(cls, value: tuple[tuple[str, str], ...]) -> tuple[tuple[str, str], ...]:
        keys = [item[0] for item in value]
        if len(keys) != len(set(keys)):
            raise ValueError("context binding keys must be unique")
        if any(not key or not val for key, val in value):
            raise ValueError("context bindings must contain non-empty strings")
        return value

    @model_validator(mode="after")
    def validate_goal_binding(self) -> "AgentSubtaskSpec":
        if (self.goal_relation is None) != (self.relation_target_ref is None):
            raise ValueError("goal_relation and relation_target_ref must be supplied together")
        if self.goal_relation is not None and self.destination_ref is not None:
            raise ValueError("relation goals cannot also bind a static destination")
        if self.goal_relation is not None and self.capability != "relation.establish":
            raise ValueError("relation goals require relation.establish capability")
        reserved = {"entity_ref", "destination_ref", "goal_relation", "relation_target_ref"}
        if reserved.intersection(key for key, _ in self.context_bindings):
            raise ValueError("context bindings cannot override semantic goal fields")
        return self


class AgentComposedPlan(BaseModel):
    """Concrete semantic DAG plus opaque entity bindings for one revision."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    version: Literal["pick_and_place_agent_plan_v1"] = AGENT_PLAN_VERSION
    mode: Literal["agent_composed"] = "agent_composed"
    graph: PlanGraph
    entity_bindings: tuple[tuple[str, str], ...] = Field(min_length=1)

    @model_validator(mode="after")
    def validate_bindings(self) -> "AgentComposedPlan":
        node_ids = {
            node.node_id for node in self.graph.nodes
            if node.node_id != "verify" and node.capability not in {
                "manipulation.process_features", "manipulation.prepare_process_features",
                "manipulation.grasp_task_affordances", "manipulation.prepare_grasp_task_affordance",
            }
        }
        bound_ids = {subtask_id for subtask_id, _ in self.entity_bindings}
        if node_ids != bound_ids:
            raise AgentPlanningError("entity bindings must cover every composed subtask exactly")
        if len(self.entity_bindings) != len(bound_ids):
            raise AgentPlanningError("entity binding identities must be unique")
        return self

    def candidate_tools(self, node_id: str, policies: tuple[ToolSpecPolicy, ...]) -> tuple[str, ...]:
        node = next((item for item in self.graph.nodes if item.node_id == node_id), None)
        if node is None:
            raise ToolSelectionError(f"unknown semantic node: {node_id}")
        return tuple(
            policy.tool_id
            for policy in policies
            if node.capability in policy.capabilities
        )


def compose_agent_plan(
    task_id: str,
    revision_id: str,
    subtasks: tuple[AgentSubtaskSpec, ...],
    *,
    planner_decision_digest: str,
    policy_snapshot_digest: str,
) -> AgentComposedPlan:
    """Compile Agent semantic subtasks into a no-motion PlanGraph."""

    if not subtasks:
        raise AgentPlanningError("agent-composed plan requires at least one subtask")
    ids = [item.subtask_id for item in subtasks]
    if len(ids) != len(set(ids)) or "verify" in set(ids):
        raise AgentPlanningError("subtask identities must be unique and cannot use verify")
    known = set(ids)
    if any(set(item.depends_on) - known for item in subtasks):
        raise AgentPlanningError("subtask dependency references an unknown subtask")
    nodes = tuple(
        PlanNode(
            node_id=item.subtask_id,
            obligation_id=item.subtask_id,
            capability=item.capability,
            dependencies=item.depends_on,
            required_evidence=item.required_evidence,
            produced_evidence=item.produced_evidence or ((f"placed:{item.entity_ref}",) if item.capability == "object.relocate" else ()),
            resources=item.resources,
            input_bindings={
                "entity_ref": item.entity_ref,
                **({"destination_ref": item.destination_ref} if item.destination_ref is not None else {}),
                **({
                    "goal_relation": item.goal_relation,
                    "relation_target_ref": item.relation_target_ref,
                } if item.goal_relation is not None else {}),
                **dict(item.context_bindings),
            },
        )
        for item in subtasks
    ) + (PlanNode(
        node_id="verify",
        obligation_id="verify-task",
        capability="task.verify",
        dependencies=tuple(ids),
    ),)
    payload = {
        "schema_version": "paos-plan-graph/v1",
        "task_id": task_id,
        "revision_id": revision_id,
        "graph_digest": "0" * 64,
        "planner_decision_digest": planner_decision_digest,
        "policy_snapshot_digest": policy_snapshot_digest,
        "nodes": [node.model_dump(mode="json") for node in nodes],
    }
    payload["graph_digest"] = plan_graph_digest(payload)
    graph = PlanGraph.model_validate(payload)
    try:
        validate_graph(graph)
    except ValueError as exc:
        raise AgentPlanningError(str(exc)) from exc
    return AgentComposedPlan(
        graph=graph,
        entity_bindings=tuple((item.subtask_id, item.entity_ref) for item in subtasks),
    )


def compose_relation_goal_plan(
    task_id: str,
    revision_id: str,
    task_goal_facts: dict[str, Any],
    *,
    subtask_id: str,
    scene_revision: str,
    observation_ref: str,
    observation_frame_id: str,
    calibration_ref: str,
    available_evidence: tuple[str, ...],
    planner_decision_digest: str,
    policy_snapshot_digest: str,
) -> AgentComposedPlan:
    """Compile one relation obligation for the current observed scene revision.

    Relation nodes are intentionally not mapped to ``object.place``. A
    provider must resolve their geometry from a fresh scene before an
    executable pick-place plan can be compiled. Completing this segment does
    not settle the parent task or authorize motion.
    """
    if (
        not isinstance(task_goal_facts, dict)
        or task_goal_facts.get("schema_version") != "paos-task-goals/v1"
        or task_goal_facts.get("motion_authorized") is not False
        or not isinstance(task_goal_facts.get("goals"), list)
    ):
        raise AgentPlanningError("task goal facts are invalid or motion-authorized")
    if any(
        not isinstance(value, str) or not value.strip()
        for value in (
            task_id, revision_id, subtask_id, scene_revision, observation_ref,
            observation_frame_id, calibration_ref,
        )
    ):
        raise AgentPlanningError("relation plan identities must be non-empty")
    if observation_ref != f"observation://{scene_revision}/{observation_frame_id}":
        raise AgentPlanningError("relation plan requires an observation bound to the current scene")
    goals_by_id: dict[str, dict[str, Any]] = {}
    for goal in task_goal_facts["goals"]:
        if not isinstance(goal, dict):
            raise AgentPlanningError("relation goal entry must be an object")
        goal_id = goal.get("subtask_id")
        if not isinstance(goal_id, str) or goal_id in goals_by_id:
            raise AgentPlanningError("relation goal identities must be unique")
        goals_by_id[goal_id] = goal
    try:
        catalog = tuple(AgentSubtaskSpec(
            subtask_id=goal["subtask_id"],
            entity_ref=goal["execution_entity_ref"],
            goal_relation=goal["goal_relation"],
            relation_target_ref=goal["relation_target_ref"],
            capability="relation.establish",
            depends_on=tuple(goal.get("depends_on", ())),
            required_evidence=tuple(goal.get("required_evidence", ())),
            produced_evidence=tuple(goal.get("produced_evidence", ())),
        ) for goal in goals_by_id.values())
    except (KeyError, TypeError, ValueError) as exc:
        raise AgentPlanningError(f"relation goal entry is invalid: {exc}") from exc
    compose_agent_plan(
        task_id,
        revision_id,
        catalog,
        planner_decision_digest=planner_decision_digest,
        policy_snapshot_digest=policy_snapshot_digest,
    )
    specs_by_id = {item.subtask_id: item for item in catalog}
    predecessor_ids = {parent for item in catalog for parent in item.depends_on}
    if any(not specs_by_id[parent].produced_evidence for parent in predecessor_ids):
        raise AgentPlanningError("relation predecessors must declare settlement evidence")
    goal = goals_by_id.get(subtask_id)
    if goal is None:
        raise AgentPlanningError(f"unknown relation subtask: {subtask_id}")
    spec = next(item for item in catalog if item.subtask_id == subtask_id)
    required = set(spec.required_evidence) | {observation_ref}
    if not required <= set(available_evidence):
        raise AgentPlanningError("relation segment lacks fresh scene or predecessor evidence")
    if any(parent not in goals_by_id for parent in spec.depends_on):
        raise AgentPlanningError("relation goal dependency references an unknown subtask")
    for parent in spec.depends_on:
        parent_evidence = set(specs_by_id[parent].produced_evidence)
        if not parent_evidence <= set(available_evidence):
            raise AgentPlanningError("relation goal predecessors are not settled")
        required.update(parent_evidence)
    node = PlanNode(
        node_id=spec.subtask_id,
        obligation_id=spec.subtask_id,
        capability="relation.establish",
        required_evidence=tuple(sorted(required)),
        produced_evidence=spec.produced_evidence,
        dependencies=(),
        input_bindings={
            "entity_ref": spec.entity_ref,
            "goal_relation": spec.goal_relation,
            "relation_target_ref": spec.relation_target_ref,
            "scene_revision": scene_revision,
            "observation_ref": observation_ref,
            "observation_frame_id": observation_frame_id,
            "calibration_ref": calibration_ref,
        },
    )
    payload = {
        "schema_version": "paos-plan-graph/v1",
        "task_id": task_id,
        "revision_id": revision_id,
        "graph_digest": "0" * 64,
        "planner_decision_digest": planner_decision_digest,
        "policy_snapshot_digest": policy_snapshot_digest,
        "nodes": [node.model_dump(mode="json")],
    }
    payload["graph_digest"] = plan_graph_digest(payload)
    graph = PlanGraph.model_validate(payload)
    try:
        validate_graph(graph)
    except ValueError as exc:
        raise AgentPlanningError(str(exc)) from exc
    return AgentComposedPlan(
        graph=graph,
        entity_bindings=((spec.subtask_id, spec.entity_ref),),
    )


_PICK_PLACE_TOOL_ORDER = (
    ("observe", "scene.observe"),
    ("capabilities", "manipulation.capabilities"),
    ("understand", "scene.understand"),
    ("grasp", "grasp.propose"),
    ("prepare", "manipulation.prepare"),
    ("acquire", "object.acquire"),
    ("place", "object.place"),
)


def compose_executable_pick_place_plan(
    task_id: str,
    revision_id: str,
    subtasks: tuple[AgentSubtaskSpec, ...],
    *,
    planner_decision_digest: str,
    policy_snapshot_digest: str,
) -> AgentComposedPlan:
    """Project Agent relocation obligations onto the existing pick-place DAG.

    This is still planning-only: nodes name frozen Tool capabilities and carry
    opaque entity bindings; Gateway invocation and task settlement stay outside
    this module. Independent subtasks may run in parallel, while each object's
    perception and manipulation stages retain the Skill-defined order.
    """
    if not subtasks:
        raise AgentPlanningError("agent-composed plan requires at least one subtask")
    ids = [item.subtask_id for item in subtasks]
    if len(ids) != len(set(ids)) or "verify" in set(ids):
        raise AgentPlanningError("subtask identities must be unique and cannot use verify")
    known = set(ids)
    if any(set(item.depends_on) - known for item in subtasks):
        raise AgentPlanningError("subtask dependency references an unknown subtask")
    if any(item.goal_relation is not None for item in subtasks):
        raise AgentPlanningError(
            "relation goals require a fresh provider-resolved target before executable pick-place compilation"
        )

    nodes: list[PlanNode] = []
    bindings: list[tuple[str, str]] = []
    for item in subtasks:
        parent_deps = tuple(f"{parent}.place" for parent in item.depends_on)
        previous = parent_deps
        for suffix, capability in _PICK_PLACE_TOOL_ORDER:
            node_id = f"{item.subtask_id}.{suffix}"
            input_bindings = {"entity_ref": item.entity_ref, **dict(item.context_bindings)}
            if item.destination_ref is not None:
                input_bindings["destination_ref"] = item.destination_ref
            node = PlanNode(
                node_id=node_id,
                obligation_id=item.subtask_id,
                capability=capability,
                dependencies=previous,
                required_evidence=item.required_evidence if suffix == "observe" else (),
                produced_evidence=(f"placed:{item.entity_ref}",) if suffix == "place" else (),
                resources=item.resources,
                input_bindings=input_bindings,
            )
            nodes.append(node)
            bindings.append((node_id, item.entity_ref))
            previous = (node_id,)
    nodes.append(PlanNode(
        node_id="verify",
        obligation_id="verify-task",
        capability="task.verify",
        dependencies=tuple(f"{item.subtask_id}.place" for item in subtasks),
    ))
    payload = {
        "schema_version": "paos-plan-graph/v1",
        "task_id": task_id,
        "revision_id": revision_id,
        "graph_digest": "0" * 64,
        "planner_decision_digest": planner_decision_digest,
        "policy_snapshot_digest": policy_snapshot_digest,
        "nodes": [node.model_dump(mode="json") for node in nodes],
    }
    payload["graph_digest"] = plan_graph_digest(payload)
    graph = PlanGraph.model_validate(payload)
    try:
        validate_graph(graph)
    except ValueError as exc:
        raise AgentPlanningError(str(exc)) from exc
    return AgentComposedPlan(graph=graph, entity_bindings=tuple(bindings))


def compose_subtask_plan(
    task_id: str,
    revision_id: str,
    subtasks: tuple[SubtaskSpec, ...],
    *,
    planner_decision_digest: str,
    policy_snapshot_digest: str,
) -> AgentComposedPlan:
    """Compile each semantic manipulation subtask into exactly one PlanNode.

    Internal acquire/prepare/process/place Tool calls remain within the
    subtask payload and are settled by the existing NodeSettlement owner.
    """
    if not subtasks:
        raise AgentPlanningError("subtask plan requires at least one subtask")
    ids = [item.subtask_id for item in subtasks]
    if len(ids) != len(set(ids)) or "verify" in set(ids):
        raise AgentPlanningError("subtask identities must be unique and cannot use verify")
    known = set(ids)
    if any(set(item.depends_on) - known for item in subtasks):
        raise AgentPlanningError("subtask dependency references an unknown subtask")

    nodes_list = []
    for item in subtasks:
        feature_node_id = f"{item.subtask_id}.process_features"
        dependencies = item.depends_on
        if item.operation in {"pour", "stir"}:
            nodes_list.append(PlanNode(
                node_id=feature_node_id,
                obligation_id=f"{item.subtask_id}-process-features",
                capability="manipulation.process_features",
                dependencies=dependencies,
                required_evidence=(item.binding.observation_ref,),
                produced_evidence=(f"process-features:{item.subtask_id}",),
                input_bindings={
                    "operation": item.operation,
                    "entity_refs": [item.binding.entity_ref,
                                    "entity://" + item.binding.destination_ref.removeprefix("destination://")
                                    .removeprefix("container://")],
                    "observation_ref": item.binding.observation_ref,
                    "scene_revision": item.binding.scene_revision,
                    "frame_id": item.binding.frame_id,
                    "calibration_ref": item.binding.calibration_ref,
                    "freshness_ms": item.binding.freshness_ms,
                    "max_age_ms": item.binding.max_age_ms,
                },
            ))
            preparation_node_id = f"{item.subtask_id}.prepare_process_features"
            nodes_list.append(PlanNode(
                node_id=preparation_node_id,
                obligation_id=f"{item.subtask_id}-process-feature-preparation",
                capability="manipulation.prepare_process_features",
                dependencies=(feature_node_id,),
                required_evidence=(item.binding.observation_ref,),
                input_bindings={
                    "operation": item.operation,
                    "entity_refs": [item.binding.entity_ref,
                                    "entity://" + item.binding.destination_ref.removeprefix("destination://")
                                    .removeprefix("container://")],
                    "observation_ref": item.binding.observation_ref,
                    "scene_revision": item.binding.scene_revision,
                    "frame_id": item.binding.frame_id,
                    "calibration_ref": item.binding.calibration_ref,
                    "freshness_ms": item.binding.freshness_ms,
                    "max_age_ms": item.binding.max_age_ms,
                },
            ))
            affordance_node_id = f"{item.subtask_id}.grasp_task_affordances"
            nodes_list.append(PlanNode(
                node_id=affordance_node_id,
                obligation_id=f"{item.subtask_id}-task-affordance-candidates",
                capability="manipulation.grasp_task_affordances",
                dependencies=(preparation_node_id,),
                required_evidence=(item.binding.observation_ref,),
                produced_evidence=(f"grasp-task-affordances:{item.subtask_id}",),
                input_bindings={
                    "operation": item.operation,
                    "entity_refs": [item.binding.entity_ref,
                                    "entity://" + item.binding.destination_ref.removeprefix("destination://")
                                    .removeprefix("container://")],
                    "grasp_candidate_set_ref": item.binding.candidate_set_ref,
                    "affordance_selection": "task_qualified",
                    "process_feature_candidate_set_ref": "process-feature-set://pending",
                    "selected_process_feature_refs": [],
                    "observation_ref": item.binding.observation_ref,
                    "scene_revision": item.binding.scene_revision,
                    "frame_id": item.binding.frame_id,
                    "calibration_ref": item.binding.calibration_ref,
                    "freshness_ms": item.binding.freshness_ms,
                    "max_age_ms": item.binding.max_age_ms,
                },
            ))
            affordance_preparation_node_id = f"{item.subtask_id}.prepare_grasp_task_affordance"
            nodes_list.append(PlanNode(
                node_id=affordance_preparation_node_id,
                obligation_id=f"{item.subtask_id}-task-affordance-preparation",
                capability="manipulation.prepare_grasp_task_affordance",
                dependencies=(affordance_node_id,),
                required_evidence=(item.binding.observation_ref,),
                input_bindings={
                    "operation": item.operation,
                    "entity_refs": [item.binding.entity_ref,
                                    "entity://" + item.binding.destination_ref.removeprefix("destination://")
                                    .removeprefix("container://")],
                    "observation_ref": item.binding.observation_ref,
                    "scene_revision": item.binding.scene_revision,
                    "frame_id": item.binding.frame_id,
                    "calibration_ref": item.binding.calibration_ref,
                    "freshness_ms": item.binding.freshness_ms,
                    "max_age_ms": item.binding.max_age_ms,
                },
            ))
            dependencies = (affordance_preparation_node_id,)
        nodes_list.append(PlanNode(
            node_id=item.subtask_id,
            obligation_id=item.subtask_id,
            capability="manipulation.execute_subtask",
            dependencies=dependencies,
            required_evidence=(item.binding.observation_ref,),
            produced_evidence=(f"subtask:{item.subtask_id}:completed",),
            input_bindings={
                **item.model_dump(mode="json", exclude_none=True,
                                  exclude={"process_feature_refs", "process_feature_candidate_set_ref",
                                           "grasp_task_affordance_candidate_set_ref",
                                           "grasp_task_affordance_ref", "selected_grasp_candidate_ref",
                                           "qualified_grasp_candidate_refs"}),
                **({"affordance_selection": "task_qualified"} if item.operation in {"pour", "stir"} else {}),
            },
        ))
    nodes = tuple(nodes_list) + (PlanNode(
        node_id="verify",
        obligation_id="verify-task",
        capability="task.verify",
        dependencies=tuple(ids),
    ),)
    payload = {
        "schema_version": "paos-plan-graph/v1",
        "task_id": task_id,
        "revision_id": revision_id,
        "graph_digest": "0" * 64,
        "planner_decision_digest": planner_decision_digest,
        "policy_snapshot_digest": policy_snapshot_digest,
        "nodes": [node.model_dump(mode="json") for node in nodes],
    }
    payload["graph_digest"] = plan_graph_digest(payload)
    graph = PlanGraph.model_validate(payload)
    try:
        validate_graph(graph)
    except ValueError as exc:
        raise AgentPlanningError(str(exc)) from exc
    return AgentComposedPlan(
        graph=graph,
        entity_bindings=tuple((item.subtask_id, item.binding.entity_ref) for item in subtasks),
    )


def select_planning_mode(mode: PlanningMode) -> PlanningMode:
    """Validate the migration switch without changing the baseline reducer."""

    if mode not in {"baseline", "agent_composed"}:
        raise AgentPlanningError(f"unsupported pick-place planning mode: {mode!r}")
    return mode


class DynamicToolPlanner:
    """Pure candidate selection/admission over a frozen Agent-composed plan."""

    def __init__(self, plan: AgentComposedPlan, policies: tuple[ToolSpecPolicy, ...]) -> None:
        if len({policy.tool_id for policy in policies}) != len(policies):
            raise AgentPlanningError("ToolSpec policy identities must be unique")
        self.plan = plan
        self.policies = policies
        self._by_id = {policy.tool_id: policy for policy in policies}

    def candidate_tools(self, node_id: str) -> tuple[str, ...]:
        candidates = self.plan.candidate_tools(node_id, self.policies)
        if not candidates:
            raise ToolSelectionError(f"no Tool candidate matches semantic node {node_id!r}")
        return candidates

    def admit(
        self,
        call: ToolCallEnvelope,
        context: AdmissionContext,
    ) -> AdmissionDecision:
        candidates = self.candidate_tools(call.node_id)
        if call.tool_id not in candidates:
            return AdmissionDecision(
                allowed=False,
                code="tool_not_declared",
                detail="Tool is not a candidate for this semantic node",
                node_id=call.node_id,
                tool_id=call.tool_id,
            )
        return admit_tool_call(self.plan.graph, call, self._by_id[call.tool_id], context)


__all__ = [
    "AGENT_PLAN_VERSION",
    "AgentComposedPlan",
    "AgentPlanningError",
    "AgentSubtaskSpec",
    "DynamicToolPlanner",
    "SemanticBindingPort",
    "PlanningMode",
    "ToolSelectionError",
    "bind_subtask_from_semantics",
    "bind_subtask_from_semantics_async",
    "compose_agent_plan",
    "compose_executable_pick_place_plan",
    "compose_relation_goal_plan",
    "compose_subtask_plan",
    "select_planning_mode",
]
