import jsonschema
import pytest
from PhyAgentOS.forge.capability_runtime import OBSERVATION_TOOL_SPEC
from PhyAgentOS.planning import project_tool_spec

from pick_place_workflow.object_acquire import ACQUIRE_TOOL_SPEC
from pick_place_workflow.object_place import PLACE_TOOL_SPEC
from pick_place_workflow.persistent_runtime import (
    AssignmentArtifactStore,
    PersistentActionEndpoint,
    PersistentPossession,
    SQLiteAssignmentArtifactStore,
    StoredAssignmentResolver,
    _ProjectedDriver,
    _spec,
    build_persistent_runtime,
)


def arguments(place=False):
    value = {"observation_ref": "observation://scene/camera", "scene_revision": "scene", "frame_id": "camera",
             "calibration_ref": "artifact://scene/calibration", "freshness_ms": 0, "max_age_ms": 1000,
             "candidate_set_ref": "candidate-set://scene/camera", "preparation_ref": "preparation://scene/camera",
             "candidate_ref": "candidate://red/0", "entity_ref": "entity://red",
             "capability_snapshot_ref": "artifact://scene/capability", "assignment_ref": "artifact://scene/assignment"}
    if place:
        value.update(acquire_invocation_ref="invocation://object-acquire/1", destination_ref="destination://red-slot")
    return value


@pytest.mark.parametrize("phase,spec", [("acquire", ACQUIRE_TOOL_SPEC), ("place", PLACE_TOOL_SPEC)])
def test_persistent_results_conform_to_published_live_schema(phase, spec):
    class Driver:
        def poll(self):
            return {"status": "succeeded", "outcome_known": True, "world_change_started": True,
                    "new_scene_revision": "scene-2", "artifact_refs": ["artifact://scene/action"]}
    result = _ProjectedDriver(Driver(), phase, arguments(phase == "place")).poll()
    live = _spec(spec)
    jsonschema.validate(result, live["output_schema"]["properties"]["result"])
    policy = project_tool_spec(live)
    assert policy.capabilities == (spec["tool_id"],)
    assert policy.input_binding_keys == (("entity_ref", "destination_ref") if phase == "place" else ("entity_ref",))


def test_owner_from_gateway_caller_is_stable_across_revision_and_record():
    seen = []
    class Client:
        def start(self, phase, invocation, owner, resolved):
            seen.append(owner)
            return object()
    endpoint = PersistentActionEndpoint("acquire", Client(), lambda phase, request: {
        **request, "assignment": {"task_id": "task-1", "assignment_ref": request["assignment_ref"]}})
    for caller in ("paos:task-1:revision-1:record-1", "paos:task-1:revision-2:record-9"):
        admission = endpoint.admit_for_caller(arguments(), caller_id=caller)
        assert not seen or seen == ["paos:task-1"]
        admission.start("invocation", "attempt")
    assert seen == ["paos:task-1", "paos:task-1"]
    with pytest.raises(ValueError, match="caller"):
        endpoint.admit_for_caller(arguments(), caller_id="diagnostic")
    with pytest.raises(ValueError, match="this task"):
        endpoint.admit_for_caller(arguments(), caller_id="paos:other:revision:record")


def test_acquire_resolver_must_load_the_canonical_prepared_assignment_ref():
    endpoint = PersistentActionEndpoint(
        "acquire",
        object(),
        lambda phase, request: {
            **request,
            "assignment": {
                "task_id": "task-1",
                "assignment_ref": "artifact://scene/different-assignment",
            },
        },
    )
    with pytest.raises(ValueError, match="assignment reference mismatch"):
        endpoint.admit_for_caller(arguments(), caller_id="paos:task-1:revision-1:record-1")


def test_place_resolver_must_load_the_latest_held_preparation_assignment_ref():
    possession = PersistentPossession(
        state="holding", owner="paos:task-1", entity_ref="entity://red",
        acquire_invocation_ref="invocation://object-acquire/1",
    )
    endpoint = PersistentActionEndpoint(
        "place", object(),
        lambda phase, request: {
            **request,
            "assignment": {
                "task_id": "task-1",
                "assignment_ref": "artifact://scene/reconstructed-assignment",
            },
        },
        possession=possession,
    )
    request = arguments(place=True)
    with pytest.raises(ValueError, match="assignment reference mismatch"):
        endpoint.admit_for_caller(request, caller_id="paos:task-1:revision-2:record-2")


def test_stored_assignment_resolver_survives_resolver_recreation_and_reads_by_ref():
    class Store(AssignmentArtifactStore):
        def __init__(self, documents):
            self.documents = dict(documents)

        def get(self, assignment_ref):
            return self.documents.get(assignment_ref)

    acquire_request = arguments()
    acquire_assignment_ref = acquire_request["assignment_ref"]
    assignment = {
        "assignment_ref": acquire_assignment_ref,
        "task_id": "task-1",
        "entity_ref": acquire_request["entity_ref"],
        "candidate_ref": acquire_request["candidate_ref"],
    }
    store = Store({acquire_assignment_ref: {
        "assignment": assignment,
        "preparation_ref": acquire_request["preparation_ref"],
        "route_arguments": dict(acquire_request),
    }})

    first_resolver = StoredAssignmentResolver(store)
    first = first_resolver.resolve_for_task("acquire", acquire_request, task_id="task-1")
    second_resolver = StoredAssignmentResolver(store)
    second = second_resolver.resolve_for_task("acquire", acquire_request, task_id="task-1")
    assert first == second
    assert first["assignment"]["assignment_ref"] == acquire_assignment_ref

    with pytest.raises(ValueError, match="not found"):
        second_resolver.resolve_for_task(
            "acquire", {**acquire_request, "assignment_ref": "artifact://scene/missing"}, task_id="task-1"
        )
    with pytest.raises(ValueError, match="another task"):
        second_resolver.resolve_for_task("acquire", acquire_request, task_id="task-2")


def test_stored_assignment_resolver_reuses_canonical_route_for_held_process():
    request = arguments()
    assignment = {
        "assignment_ref": request["assignment_ref"],
        "task_id": "task-1",
        "entity_ref": request["entity_ref"],
        "candidate_ref": request["candidate_ref"],
        "scene_revision": request["scene_revision"],
    }
    document = {
        "assignment": assignment,
        "preparation_ref": request["preparation_ref"],
        "route_arguments": dict(request),
    }

    class Store:
        def get(self, reference):
            return document if reference == request["assignment_ref"] else None

    held_request = {
        **request,
        "operation": "pour",
        "parameters": {"tilt_rad": 0.8, "hold_s": 0.5},
        "scene_revision": "scene-after-acquire",
        "acquire_invocation_ref": "invocation://object-acquire/1",
        "held_invocation_ref": "invocation://manipulation-pour/1",
    }
    resolved = StoredAssignmentResolver(Store()).resolve_for_task(
        "pour", held_request, task_id="task-1"
    )
    assert resolved["assignment"] == assignment
    assert resolved["assignment_ref"] == request["assignment_ref"]
    assert resolved["entity_ref"] == request["entity_ref"]
    assert resolved["scene_revision"] == "scene-after-acquire"
    assert resolved["parameters"] == held_request["parameters"]


def test_persistent_action_endpoint_passes_caller_task_to_stored_resolver():
    request = arguments()
    document = {
        "assignment": {
            "assignment_ref": request["assignment_ref"],
            "task_id": "task-1",
            "entity_ref": request["entity_ref"],
            "candidate_ref": request["candidate_ref"],
        },
        "preparation_ref": request["preparation_ref"],
        "route_arguments": dict(request),
    }

    class Store:
        def get(self, reference):
            return document if reference == request["assignment_ref"] else None

    endpoint = PersistentActionEndpoint(
        "acquire", object(), StoredAssignmentResolver(Store())
    )
    admission = endpoint.admit_for_caller(
        request, caller_id="paos:task-1:revision-1:record-1"
    )
    assert admission is not None


def test_stored_assignment_resolver_rejects_route_from_another_preparation_scene():
    request = arguments(place=True)
    assignment = {
        "assignment_ref": request["assignment_ref"],
        "task_id": "task-1",
        "entity_ref": request["entity_ref"],
        "candidate_ref": request["candidate_ref"],
        "scene_revision": request["scene_revision"],
    }
    document = {
        "assignment": assignment,
        "preparation_ref": request["preparation_ref"],
        "route_arguments": {
            **request,
            "scene_revision": "different-scene",
        },
    }

    class Store:
        def get(self, _reference):
            return document

    with pytest.raises(ValueError, match="assignment scene_revision"):
        StoredAssignmentResolver(Store()).resolve_for_task(
            "place", request, task_id="task-1"
        )


def test_sqlite_assignment_store_survives_close_and_reopen(tmp_path):
    request = arguments()
    document = {
        "assignment": {
            "assignment_ref": request["assignment_ref"],
            "task_id": "task-1",
            "entity_ref": request["entity_ref"],
            "candidate_ref": request["candidate_ref"],
        },
        "preparation_ref": request["preparation_ref"],
        "route_arguments": dict(request),
    }
    db_path = tmp_path / "assignments.sqlite3"
    first = SQLiteAssignmentArtifactStore(db_path)
    first.put(request["assignment_ref"], document)
    first.close()

    second = SQLiteAssignmentArtifactStore(db_path)
    try:
        resolved = StoredAssignmentResolver(second).resolve_for_task(
            "acquire", request, task_id="task-1"
        )
        assert resolved["assignment"] == document["assignment"]
        assert resolved["preparation_ref"] == request["preparation_ref"]
    finally:
        second.close()


def test_stored_assignment_resolution_retains_adapter_live_route_validation():
    request = arguments()
    document = {
        "assignment": {
            "assignment_ref": request["assignment_ref"],
            "task_id": "task-1",
            "entity_ref": request["entity_ref"],
            "candidate_ref": request["candidate_ref"],
        },
        "preparation_ref": request["preparation_ref"],
        "route_arguments": dict(request),
    }

    class Store:
        def get(self, assignment_ref):
            return document if assignment_ref == request["assignment_ref"] else None

    class RouteValidator:
        def __init__(self):
            self.calls = []

        def resolve_stored(self, phase, arguments, route_arguments, *, task_id):
            self.calls.append((phase, task_id, route_arguments["assignment_ref"]))
            raise ValueError("live route approval is unavailable")

    validator = RouteValidator()
    resolver = StoredAssignmentResolver(Store(), route_validator=validator)
    with pytest.raises(ValueError, match="live route approval"):
        resolver.resolve_for_task("acquire", request, task_id="task-1")
    assert validator.calls == [
        ("acquire", "task-1", request["assignment_ref"])
    ]


def test_sqlite_assignment_store_does_not_replace_a_canonical_ref(tmp_path):
    request = arguments()
    document = {
        "assignment": {
            "assignment_ref": request["assignment_ref"],
            "task_id": "task-1",
            "entity_ref": request["entity_ref"],
            "candidate_ref": request["candidate_ref"],
        },
        "preparation_ref": request["preparation_ref"],
        "route_arguments": dict(request),
    }
    with SQLiteAssignmentArtifactStore(tmp_path / "assignments.sqlite3") as store:
        store.put(request["assignment_ref"], document)
        store.put(request["assignment_ref"], document)
        with pytest.raises(ValueError, match="different artifact"):
            store.put(request["assignment_ref"], {
                **document,
                "route_arguments": {**request, "scene_revision": "other-scene"},
            })


def test_build_runtime_prefers_injected_store_for_action_resolution(tmp_path):
    class Providers:
        def describe(self, _request):
            return None

        def understand(self, _request):
            return None

        def propose(self, _request):
            return None

        def prepare(self, _request):
            return None

    store = SQLiteAssignmentArtifactStore(tmp_path / "assignments.sqlite3")
    provider = Providers()
    try:
        runtime = build_persistent_runtime(
            client=object(), understanding_provider=provider, grasp_provider=provider,
            preparation_provider=provider, capability_provider=provider,
            resolve_preparation=lambda _phase, _request: (_ for _ in ()).throw(
                AssertionError("legacy resolver must not be used")),
            assignment_store=store,
            tool_context_provider=lambda _tool_id: {"ready": False},
        )
        assert runtime.get_tool("object.acquire")["tool_id"] == "object.acquire"
    finally:
        store.close()


def test_composition_registers_all_seven_required_tools():
    from pick_place_workflow.persistent_runtime import build_persistent_runtime

    class Providers:
        def describe(self, request):
            return None

        def understand(self, request):
            return None

        def propose(self, request):
            return None

        def prepare(self, request):
            return None

    provider = Providers()
    runtime = build_persistent_runtime(
        client=object(), understanding_provider=provider, grasp_provider=provider,
        preparation_provider=provider, capability_provider=provider,
        resolve_preparation=lambda phase, request: request,
        tool_context_provider=lambda tool_id: {"ready": False, "binding_error": "not started"},
        tool_input_defaults={
            "scene.observe": {"sensor_ref": "camera/head", "max_age_ms": 1000}
        },
    )
    tools = {tool["tool_id"]: tool for tool in runtime.list_tools()["tools"]}
    assert set(tools) == {
        "scene.observe", "scene.understand", "grasp.propose", "manipulation.capabilities",
        "manipulation.prepare", "object.acquire", "object.place",
    }
    observe_schema = tools["scene.observe"]["input_schema"]
    assert observe_schema["properties"]["sensor_ref"]["default"] == "camera/head"
    assert observe_schema["properties"]["max_age_ms"]["default"] == 1000
    assert observe_schema["required"] == ["max_age_ms"]
    assert observe_schema["oneOf"] == [
        {"required": ["sensor_ref"], "not": {"required": ["sensor_refs"]}},
        {"required": ["sensor_refs"], "not": {"required": ["sensor_ref"]}},
    ]
    for tool in runtime.list_tools()["tools"]:
        capabilities = project_tool_spec(tool).capabilities
        if tool["tool_id"] == "scene.observe":
            assert capabilities == ("scene.observe", "task.verify")
        else:
            assert capabilities == (tool["tool_id"],)
        assert "object.relocate" not in capabilities
    prepare = next(
        tool
        for tool in runtime.list_tools()["tools"]
        if tool["tool_id"] == "manipulation.prepare"
    )
    assert prepare["default_timeout_ms"] == 360_000
    prepare_policy = project_tool_spec(prepare)
    assert prepare_policy.argument_projection == "candidate_set_for_entity_v1"
    assert prepare_policy.argument_projection_plan is not None
    assert (
        prepare_policy.argument_projection_plan.source_slots["candidates"].filtered_output_field
        == "candidates"
    )
    assert all(runtime.get_context(tool["tool_id"])["ready"] is False for tool in runtime.list_tools()["tools"])


def test_build_runtime_composes_artifact_resolving_understanding_provider(tmp_path):
    from PhyAgentOS.forge.artifacts import LocalFilesystemArtifactResolver

    (tmp_path / "rgb").mkdir()
    (tmp_path / "rgb/front.png").write_bytes(b"image-bytes")

    class Providers:
        def propose(self, _request):
            return None

        def describe(self, _request):
            return None

        def prepare(self, _request):
            return None

    seen = []
    runtime = build_persistent_runtime(
        client=object(),
        understanding_artifact_resolver=LocalFilesystemArtifactResolver({"store": tmp_path}),
        understanding_inference=lambda payload: seen.append(payload) or {"entities": []},
        grasp_provider=Providers(),
        preparation_provider=Providers(),
        capability_provider=Providers(),
        resolve_preparation=lambda _phase, request: request,
        tool_context_provider=lambda _tool_id: {"ready": True},
        register_legacy_actions=False,
        register_legacy_held_operations=False,
    )
    result = runtime.invoke_query("scene_understanding", "understand", {
        "observation_ref": "observation://scene/camera",
        "scene_revision": "scene",
        "frame_id": "camera",
        "calibration_ref": "artifact://store/calibration.json",
        "freshness_ms": 10,
        "max_age_ms": 100,
        "artifacts": ["artifact://store/rgb/front.png"],
    })

    assert result["status"] == "available"
    assert seen[0]["resolved_artifacts"][0]["data"] == b"image-bytes"
    assert seen[0]["resolved_artifacts"][0]["media_type"] == "image/png"


def test_build_runtime_composes_registry_selected_understanding_inference(tmp_path):
    from PhyAgentOS.forge.artifacts import LocalFilesystemArtifactResolver
    from PhyAgentOS.forge.capability_runtime import SceneUnderstandingInferenceRegistry

    (tmp_path / "rgb").mkdir()
    (tmp_path / "rgb/front.png").write_bytes(b"image-bytes")

    class Providers:
        def propose(self, _request):
            return None

        def describe(self, _request):
            return None

        def prepare(self, _request):
            return None

    seen = []

    class Factory:
        inference_id = "fixture"

        def create(self, *, configuration):
            seen.append(("configuration", configuration))
            return lambda request: seen.append(("inference", request)) or {"entities": []}

    registry = SceneUnderstandingInferenceRegistry()
    registry.register(Factory())
    runtime = build_persistent_runtime(
        client=object(),
        understanding_artifact_resolver=LocalFilesystemArtifactResolver({"store": tmp_path}),
        understanding_inference_registry=registry,
        understanding_inference_id="fixture",
        understanding_inference_configuration={"deployment": "test"},
        grasp_provider=Providers(),
        preparation_provider=Providers(),
        capability_provider=Providers(),
        resolve_preparation=lambda _phase, request: request,
        tool_context_provider=lambda _tool_id: {"ready": True},
        register_legacy_actions=False,
        register_legacy_held_operations=False,
    )

    result = runtime.invoke_query("scene_understanding", "understand", {
        "observation_ref": "observation://scene/camera",
        "scene_revision": "scene",
        "frame_id": "camera",
        "calibration_ref": "artifact://store/calibration.json",
        "freshness_ms": 10,
        "max_age_ms": 100,
        "artifacts": ["artifact://store/rgb/front.png"],
    })

    assert result["status"] == "available"
    assert seen[0] == ("configuration", {"deployment": "test"})
    assert seen[1][0] == "inference"
    assert seen[1][1]["resolved_artifacts"][0]["data"] == b"image-bytes"


@pytest.mark.parametrize(
    "provider,resolver,inference",
    [
        (None, object(), None),
        (object(), object(), object()),
    ],
)
def test_build_runtime_rejects_incomplete_or_ambiguous_understanding_composition(
    provider, resolver, inference
):
    class Providers:
        def propose(self, _request):
            return None

        def describe(self, _request):
            return None

        def prepare(self, _request):
            return None

    with pytest.raises(ValueError, match="understanding_provider|not both|composition"):
        build_persistent_runtime(
            client=object(),
            understanding_provider=provider,
            understanding_artifact_resolver=resolver,
            understanding_inference=inference,
            grasp_provider=Providers(),
            preparation_provider=Providers(),
            capability_provider=Providers(),
            resolve_preparation=lambda _phase, request: request,
            tool_context_provider=lambda _tool_id: {"ready": True},
        )


@pytest.mark.parametrize(
    "resolver,registry,inference_id",
    [
        (None, object(), "fixture"),
        (object(), None, "fixture"),
        (object(), object(), None),
    ],
)
def test_build_runtime_rejects_incomplete_registry_composition(resolver, registry, inference_id):
    class Providers:
        def propose(self, _request):
            return None

        def describe(self, _request):
            return None

        def prepare(self, _request):
            return None

    with pytest.raises(ValueError, match="composition is required"):
        build_persistent_runtime(
            client=object(),
            understanding_artifact_resolver=resolver,
            understanding_inference_registry=registry,
            understanding_inference_id=inference_id,
            grasp_provider=Providers(),
            preparation_provider=Providers(),
            capability_provider=Providers(),
            resolve_preparation=lambda _phase, request: request,
            tool_context_provider=lambda _tool_id: {"ready": True},
        )


def test_projected_action_diagnostics_do_not_expose_prepared_trajectory():
    class Driver:
        def poll(self):
            return {
                "status": "failed",
                "outcome_known": True,
                "world_change_started": False,
                "failure_owner": "planner",
                "failure_code": "route_failed",
                "recommended_action": "stop",
                "arm_attempts": [{
                    "arm": "arm-a",
                    "status": "fail",
                    "failed_phase": "approach",
                    "failed_waypoint_index": 0,
                    "detail": "no route",
                    "execution_plan": {"segments": [[[1.0] * 7]]},
                    "segments": [{"end_qpos": [1.0] * 7}],
                }],
            }

    result = _ProjectedDriver(Driver(), "acquire", arguments()).poll()
    attempts = result["capability_outcome_summary"]["arm_attempts"]
    assert attempts == [{
        "arm": "arm-a",
        "status": "fail",
        "failed_phase": "approach",
        "failed_waypoint_index": 0,
        "detail": "no route",
    }]
    assert "execution_plan" not in str(result)


def test_tool_defaults_must_target_declared_input_fields():
    with pytest.raises(ValueError, match="declared input fields"):
        _spec(ACQUIRE_TOOL_SPEC, argument_defaults={"sensor_ref": "camera/head"})


def test_pick_place_runtime_can_require_synchronized_observations_without_globalizing_core_policy():
    spec = _spec(
        OBSERVATION_TOOL_SPEC,
        argument_defaults={"sensor_refs": ["camera/head", "camera/front"], "max_age_ms": 1000},
        require_synchronized_views=True,
    )
    schema = spec["input_schema"]
    assert "sensor_ref" not in schema["properties"]
    assert schema["properties"]["sensor_refs"]["minItems"] == 2
    assert schema["oneOf"] == [{"required": ["sensor_refs"]}]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate({"sensor_ref": "camera/head", "max_age_ms": 1000}, schema)
    jsonschema.validate(
        {"sensor_refs": ["camera/head", "camera/front"], "max_age_ms": 1000},
        schema,
    )


def test_persistent_observation_source_prefers_capture_and_supports_legacy_query_port():
    from pick_place_workflow.persistent_runtime import PersistentObservationSource

    request = {"sensor_ref": "camera/front", "max_age_ms": 1000}

    class CaptureSource:
        def __init__(self):
            self.requests = []

        def capture(self, value):
            self.requests.append(value)
            return {"source": "capture", **value}

    class QuerySource:
        def __init__(self):
            self.calls = []

        def query(self, operation, value):
            self.calls.append((operation, value))
            return {"source": "query", **value}

    capture = CaptureSource()
    assert PersistentObservationSource(capture).capture(request) == {"source": "capture", **request}
    assert capture.requests == [request]

    query = QuerySource()
    assert PersistentObservationSource(query).capture(request) == {"source": "query", **request}
    assert query.calls == [("observe", request)]


def test_persistent_observation_source_rejects_action_only_client():
    from pick_place_workflow.persistent_runtime import PersistentObservationSource

    with pytest.raises(TypeError, match="observation source"):
        PersistentObservationSource(object()).capture({"sensor_ref": "camera/front"})


def test_unknown_place_cannot_produce_semantic_completion_evidence():
    class Driver:
        def poll(self):
            return {"status": "succeeded", "outcome_known": False, "artifact_refs": ["artifact://scene/partial"]}

    result = _ProjectedDriver(Driver(), "place", arguments(True)).poll()
    assert result["status"] == "unknown"
    assert result["evidence_refs"] == ["artifact://scene/partial"]
    assert result["capability_outcome_summary"]["post_release_evidence"]["availability"] == "none"


@pytest.mark.parametrize(
    "missing_field",
    ["release_confirmed", "retreat_completed", "clear_of_target", "observation_ready"],
)
def test_place_success_without_any_postcondition_remains_unknown(missing_field):
    class Driver:
        def poll(self):
            result = {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "new_scene_revision": "scene-2",
                "artifact_refs": ["artifact://scene-2/place"],
                "release_confirmed": True,
                "retreat_completed": True,
                "clear_of_target": True,
                "observation_ready": True,
            }
            result[missing_field] = False
            return result

    result = _ProjectedDriver(Driver(), "place", arguments(True)).poll()
    assert result["status"] == "unknown"
    assert result["capability_outcome_summary"]["failure_code"] == "missing_place_postconditions"
    assert result["capability_outcome_summary"]["outcome_known"] is False


def test_evidence_free_success_does_not_complete_relocate():
    class Driver:
        def poll(self):
            return {"status": "succeeded", "outcome_known": True, "world_change_started": True}

    result = _ProjectedDriver(Driver(), "place", arguments(True)).poll()
    assert result["status"] == "unknown"
    assert result["evidence_refs"] == []
    assert result["capability_outcome_summary"]["outcome_known"] is False
    assert result["capability_outcome_summary"]["world_change_started"] is True


def test_persistent_possession_requires_acquire_then_matching_place():
    possession = PersistentPossession()
    possession.begin("acquire", owner="paos:task", entity_ref="entity://red")
    assert possession.state == "acquiring"
    possession.settle("acquire", {"status": "succeeded", "outcome_known": True, "world_change_started": True})
    assert possession.state == "holding"
    with pytest.raises(ValueError, match="does not match"):
        possession.validate_begin("place", owner="paos:other", entity_ref="entity://red", acquire_ref=None)
    possession.acquire_invocation_ref = "invocation://object-acquire/abc"
    possession.validate_begin("place", owner="paos:task", entity_ref="entity://red", acquire_ref="invocation://object-acquire/abc")
    possession.begin("place", owner="paos:task", entity_ref="entity://red", acquire_ref="invocation://object-acquire/abc")
    assert possession.state == "placing"
    possession.settle("place", {"status": "succeeded", "outcome_known": True, "world_change_started": True})
    assert possession.state == "empty"


def test_uncertain_possession_blocks_second_acquire_and_preserves_owner():
    possession = PersistentPossession()
    possession.begin("acquire", owner="paos:task", entity_ref="entity://red")
    possession.settle("acquire", {"status": "unknown", "outcome_known": False, "world_change_started": True})
    assert possession.state == "uncertain"
    with pytest.raises(ValueError, match="not admissible"):
        possession.validate_begin("acquire", owner="paos:task", entity_ref="entity://blue")
    assert possession.owner == "paos:task"
    assert possession.entity_ref == "entity://red"


def test_cancel_or_stop_without_physical_confirmation_does_not_release():
    possession = PersistentPossession()
    possession.begin("acquire", owner="paos:task", entity_ref="entity://red")
    possession.settle("acquire", {"status": "cancelled", "outcome_known": False, "world_change_started": True})
    assert possession.state == "uncertain"


def test_place_projects_current_scene_while_retaining_acquire_provenance():
    class Driver:
        def poll(self):
            return {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "artifact_refs": ["artifact://scene-2/place"],
                "new_scene_revision": "scene-3",
            }

    source = arguments(True)
    result = _ProjectedDriver(
        Driver(), "place", source, current_scene_revision="scene-2"
    ).poll()
    assert result["scene_revision"] == "scene"
    assert result["current_scene_revision"] == "scene-2"
    assert result["candidate_ref"] == source["candidate_ref"]
    assert result["preparation_ref"] == source["preparation_ref"]
    assert result["acquire_invocation_ref"] == source["acquire_invocation_ref"]


def test_acquire_result_uses_gateway_envelope_for_invocation_identity():
    class Driver:
        def poll(self):
            return {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "artifact_refs": ["artifact://scene-2/acquire"],
                "new_scene_revision": "scene-2",
            }

    result = _ProjectedDriver(
        Driver(), "acquire", arguments(), invocation_id="invocation://object-acquire/1"
    ).poll()

    assert result["new_scene_revision"] == "scene-2"
    assert "acquire_invocation_ref" not in result


def test_acquire_world_change_without_effect_scene_remains_physically_unknown():
    class Driver:
        def poll(self):
            return {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "artifact_refs": ["artifact://scene-2/acquire"],
            }

    result = _ProjectedDriver(Driver(), "acquire", arguments()).poll()
    summary = result["capability_outcome_summary"]

    assert result["status"] == "unknown"
    assert "new_scene_revision" not in result
    assert summary["failure_owner"] == "execution"
    assert summary["failure_code"] == "missing_new_scene_revision"
    assert summary["world_change_started"] is True
    assert summary["outcome_known"] is False


def test_restart_reconciliation_restores_only_explicit_matching_holding():
    possession = PersistentPossession(
        state="uncertain",
        owner="paos:task",
        entity_ref="entity://red",
        acquire_invocation_ref="invocation://object-acquire/abc",
    )
    snapshot = {
        "available": True,
        "holding_state": "holding",
        "owner": "paos:task",
        "entity_ref": "entity://red",
        "acquire_invocation_ref": "invocation://object-acquire/abc",
    }
    assert possession.reconcile(snapshot) == "holding"
    mismatch = {**snapshot, "entity_ref": "entity://blue"}
    assert possession.reconcile(mismatch) == "uncertain"


def test_restart_reconciliation_empty_is_explicit_and_disconnect_never_releases():
    possession = PersistentPossession(
        state="uncertain",
        owner="paos:task",
        entity_ref="entity://red",
        acquire_invocation_ref="invocation://object-acquire/abc",
    )
    assert possession.reconcile({"available": False}) == "uncertain"
    assert possession.entity_ref == "entity://red"
    assert possession.reconcile({"available": True, "holding_state": "empty"}) == "empty"
    assert possession.entity_ref is None
