"""Provider-neutral bounded object acquisition Action contract."""

from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from typing import Any, Protocol

ACQUIRE_TOOL_ID = "object.acquire"
ACQUIRE_ENDPOINT_ID = "object_acquisition"
ACQUIRE_OPERATION = "acquire"
CAPABILITY_OUTCOME_SUMMARY_VERSION = "capability_outcome_summary_v1"

_OBSERVATION_REF = re.compile(r"^observation://[^/]+/[^/]+$")
_CANDIDATE_SET_REF = re.compile(r"^candidate-set://[^/]+/.+$")
_PREPARATION_REF = re.compile(r"^preparation://[^/]+/.+$")
_CANDIDATE_REF = re.compile(r"^candidate://[^/]+/.+$")
_ENTITY_REF = re.compile(r"^entity://[^/]+$")
_ARTIFACT_REF = re.compile(r"^artifact://[^/]+/.+$")
_METRIC_NAME = re.compile(r"^[a-z][a-z0-9_]{0,63}$")

_CAPABILITY_PHASES = ("approach", "contact", "close", "lift", "hold", "none")
_TERMINAL_STATUSES = ("succeeded", "failed", "cancelled", "stopped", "unknown")
_FAILURE_OWNERS = (
    "none",
    "input",
    "binding",
    "readiness",
    "planner",
    "execution",
    "execution_verification",
    "evidence",
    "settlement",
    "operator",
    "infrastructure",
)
_EVIDENCE_AVAILABILITY = ("complete", "partial", "none", "unknown")


def _ref_frame_id(reference: str, scheme: str) -> str:
    """Return the terminal observation-frame component of a provenance URI."""
    return reference.removeprefix(f"{scheme}://").split("/")[-1]

_SUMMARY_KEYS = {
    "version",
    "capability_phase",
    "status",
    "failure_owner",
    "failure_code",
    "world_change_started",
    "outcome_known",
    "evidence_availability",
    "artifact_refs",
    "bounded_metric_names",
    "retryable_in_revision",
    "requires_replan",
    "recommended_action",
    "phase",
    "selected_arm",
    "failed_phase",
    "arm_attempts",
    "evidence_refs",
}


class AcquireProvider(Protocol):
    """Gateway-side provider that starts one bounded acquire execution."""

    def acquire(self, request: dict[str, Any]) -> "AcquireSnapshot | None": ...


class ActionReadinessGate(Protocol):
    """Validate immutable readiness evidence before provider admission."""

    def check(self, request: dict[str, Any]) -> str | None: ...


@dataclass(frozen=True)
class AcquireSnapshot:
    """Provider-neutral terminal facts plus an internal fake pending budget."""

    capability_phase: str = "hold"
    status: str = "succeeded"
    failure_owner: str | None = None
    failure_code: str | None = None
    world_change_started: bool = False
    outcome_known: bool = True
    new_scene_revision: str | None = None
    evidence_availability: str = "none"
    artifact_refs: tuple[str, ...] = field(default_factory=tuple)
    bounded_metric_names: tuple[str, ...] = field(default_factory=tuple)
    retryable_in_revision: bool = False
    requires_replan: bool = False
    recommended_action: str = "continue"
    phase: str = "acquire"
    selected_arm: str | None = None
    failed_phase: str | None = None
    arm_attempts: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    possession_state: str | None = None
    object_support_state: str | None = None
    acquisition_measurement: dict[str, float] | None = None
    pending_polls: int = 0
    provider_available: bool = True


@dataclass(frozen=True)
class AcquireAdmission:
    """Validated provider plan held by the Gateway invocation owner."""

    snapshot: AcquireSnapshot
    terminal_result: dict[str, Any]


@dataclass(frozen=True)
class AcquireRejection:
    """HTTP rejection that occurs before an Action invocation is created."""

    status_code: int
    code: str
    message: str


_INPUT_KEYS = {
    "observation_ref",
    "scene_revision",
    "frame_id",
    "calibration_ref",
    "freshness_ms",
    "max_age_ms",
    "candidate_set_ref",
    "preparation_ref",
    "candidate_ref",
    "entity_ref",
    "capability_snapshot_ref",
    "assignment_ref",
}


def _summary_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": sorted(_SUMMARY_KEYS),
        "properties": {
            "version": {"const": CAPABILITY_OUTCOME_SUMMARY_VERSION},
            "capability_phase": {"enum": list(_CAPABILITY_PHASES)},
            "status": {"enum": list(_TERMINAL_STATUSES)},
            "failure_owner": {"enum": list(_FAILURE_OWNERS) + [None]},
            "failure_code": {"type": ["string", "null"]},
            "world_change_started": {"type": "boolean"},
            "outcome_known": {"type": "boolean"},
            "evidence_availability": {"enum": list(_EVIDENCE_AVAILABILITY)},
            "artifact_refs": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            },
            "bounded_metric_names": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^[a-z][a-z0-9_]{0,63}$"},
            },
            "retryable_in_revision": {"type": "boolean"},
            "requires_replan": {"type": "boolean"},
            "recommended_action": {"type": "string", "minLength": 1},
            "phase": {"type": "string", "minLength": 1},
            "selected_arm": {"type": ["string", "null"]},
            "failed_phase": {"type": ["string", "null"]},
            "arm_attempts": {"type": "array", "items": _arm_attempt_schema()},
            "evidence_refs": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            },
            "possession_state": {"enum": ["empty", "holding", None]},
            "object_support_state": {"enum": ["on_support", "displaced", "unknown", None]},
            "acquisition_measurement": {
                "type": ["object", "null"],
                "additionalProperties": False,
                "required": [
                    "lift_displacement_m",
                    "minimum_lift_m",
                    "support_clearance_m",
                    "support_tolerance_m",
                ],
                "properties": {
                    "lift_displacement_m": {"type": "number"},
                    "minimum_lift_m": {"type": "number", "exclusiveMinimum": 0},
                    "support_clearance_m": {"type": "number"},
                    "support_tolerance_m": {"type": "number", "minimum": 0},
                },
            },
        },
    }


def _arm_attempt_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["arm", "status"],
        "properties": {
            "arm": {"type": "string", "minLength": 1},
            "status": {"enum": ["pass", "fail"]},
            "failed_phase": {"type": ["string", "null"]},
            "failed_waypoint_index": {"type": ["integer", "null"], "minimum": 0},
            "detail": {"type": ["string", "null"]},
        },
    }


def validate_recovery_arm_attempts(value: Any) -> bool:
    allowed = {"arm", "status", "failed_phase", "failed_waypoint_index", "detail"}
    if not isinstance(value, (tuple, list)):
        return False
    for item in value:
        if not isinstance(item, dict) or set(item) - allowed:
            return False
        if not isinstance(item.get("arm"), str) or not item["arm"].strip():
            return False
        if item.get("status") not in {"pass", "fail"}:
            return False
        if item.get("failed_phase") is not None and not isinstance(item["failed_phase"], str):
            return False
        index = item.get("failed_waypoint_index")
        if index is not None and (
            isinstance(index, bool) or not isinstance(index, int) or index < 0
        ):
            return False
        if item.get("detail") is not None and not isinstance(item["detail"], str):
            return False
    return True


def _terminal_result_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "allOf": [
            {
                "if": {
                    "properties": {
                        "status": {"const": "succeeded"},
                        "capability_outcome_summary": {
                            "properties": {
                                "world_change_started": {"const": True},
                                "outcome_known": {"const": True},
                            },
                            "required": ["world_change_started", "outcome_known"],
                        },
                    },
                    "required": ["status", "capability_outcome_summary"],
                },
                "then": {"required": ["new_scene_revision"]},
            }
        ],
        "required": [
            "status",
            "observation_ref",
            "scene_revision",
            "frame",
            "calibration_ref",
            "candidate_set_ref",
            "preparation_ref",
            "candidate_ref",
            "entity_ref",
            "capability_snapshot_ref",
            "assignment_ref",
            "capability_outcome_summary",
        ],
        "properties": {
            "status": {"enum": list(_TERMINAL_STATUSES)},
            "observation_ref": {
                "type": "string",
                "pattern": r"^observation://[^/]+/[^/]+$",
            },
            "scene_revision": {"type": "string", "minLength": 1},
            "new_scene_revision": {"type": "string", "minLength": 1},
            "frame": {
                "type": "object",
                "additionalProperties": False,
                "required": ["frame_id", "unit"],
                "properties": {
                    "frame_id": {"type": "string", "minLength": 1},
                    "unit": {"const": "m"},
                },
            },
            "calibration_ref": {"type": "string", "minLength": 1},
            "candidate_set_ref": {
                "type": "string",
                "pattern": r"^candidate-set://[^/]+/.+$",
            },
            "preparation_ref": {
                "type": "string",
                "pattern": r"^preparation://[^/]+/.+$",
            },
            "candidate_ref": {"type": "string", "pattern": r"^candidate://[^/]+/.+$"},
            "entity_ref": {"type": "string", "pattern": r"^entity://[^/]+$"},
            "capability_snapshot_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            "assignment_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            "capability_outcome_summary": _summary_schema(),
        },
    }


ACQUIRE_TOOL_SPEC: dict[str, Any] = {
    "tool_id": ACQUIRE_TOOL_ID,
    "implementation_id": "object.acquisition",
    "endpoint_id": ACQUIRE_ENDPOINT_ID,
    "operation": ACQUIRE_OPERATION,
    "semantics": "action",
    "planning": {
        "schema_version": "paos-tool-spec-policy/v1",
        "capabilities": [ACQUIRE_TOOL_ID],
        "scene_write_behavior": "new_revision",
        "input_binding_keys": ["entity_ref"],
        "argument_projection": "prepared_assignment_action_v1",
        "argument_projection_plan": {
            "projection_id": "prepared_assignment_action_v1",
            "join_field": "entity_ref",
            "source_slots": {
                "preparation": {
                    "tool_id": "manipulation.prepare",
                    "source_scope": "predecessor",
                    "source_field_map": {
                        "observation_ref": ["observation_ref"],
                        "scene_revision": ["scene_revision"],
                        "frame_id": ["frame", "frame_id"],
                        "calibration_ref": ["calibration_ref"],
                        "freshness_ms": ["freshness_ms"],
                        "max_age_ms": ["max_age_ms"],
                        "candidate_set_ref": ["candidate_set_ref"],
                        "preparation_ref": ["preparation_ref"],
                    },
                    "unique_item_collection": ["assignments"],
                    "unique_item_join_field": "entity_ref",
                    "unique_item_field_map": {
                        "candidate_ref": ["candidate_ref"],
                        "capability_snapshot_ref": ["capability_snapshot_ref"],
                        "assignment_ref": ["assignment_ref"],
                    },
                }
            },
            "top_level_fields": ["entity_ref"],
        },
    },
    "description": (
        "Admit one bounded object acquisition workflow using a prepared grasp reference; "
        "approach, contact, close, lift, and hold remain internal Gateway phases."
    ),
    "input_schema": {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "observation_ref",
            "scene_revision",
            "frame_id",
            "calibration_ref",
            "freshness_ms",
            "max_age_ms",
            "candidate_set_ref",
            "preparation_ref",
            "candidate_ref",
            "entity_ref",
            "capability_snapshot_ref",
            "assignment_ref",
        ],
        "properties": {
            "observation_ref": {"type": "string", "pattern": r"^observation://[^/]+/[^/]+$"},
            "scene_revision": {"type": "string", "minLength": 1},
            "frame_id": {"type": "string", "minLength": 1},
            "calibration_ref": {"type": "string", "minLength": 1},
            "freshness_ms": {"type": "integer", "minimum": 0},
            "max_age_ms": {"type": "integer", "minimum": 1},
            "candidate_set_ref": {
                "type": "string",
                "pattern": r"^candidate-set://[^/]+/.+$",
            },
            "preparation_ref": {"type": "string", "pattern": r"^preparation://[^/]+/.+$"},
            "candidate_ref": {"type": "string", "pattern": r"^candidate://[^/]+/.+$"},
            "entity_ref": {"type": "string", "pattern": r"^entity://[^/]+$"},
            "capability_snapshot_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            "assignment_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
        },
    },
    "output_schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["invocation_id", "attempt_id", "phase"],
        "properties": {
            "invocation_id": {"type": "string", "pattern": r"^invocation://[^/]+/.+$"},
            "attempt_id": {"type": "string", "pattern": r"^attempt://[^/]+/.+$"},
            "phase": {
                "enum": ["accepted", "running", "completed", "failed", "cancelled", "stopped", "unknown"]
            },
            "cancel_requested": {"type": "boolean"},
            "result": _terminal_result_schema(),
        },
    },
    "robot_frame_profile": {
        "observation_frame": "observation",
        "unit": "m",
        "orientation_convention": "candidate-bound",
    },
    "max_concurrency": 1,
    "cancellation": "supported_via_common_cancel_route",
    "unknown_semantics": "terminal_for_accounting_not_physical_stop",
}


def validate_arguments(arguments: Any) -> str | None:
    """Validate all Action inputs before provider or invocation allocation."""

    if not isinstance(arguments, dict):
        return "invalid_arguments"
    if set(arguments) != _INPUT_KEYS:
        return "invalid_arguments"
    observation_ref = arguments.get("observation_ref")
    scene_revision = arguments.get("scene_revision")
    frame_id = arguments.get("frame_id")
    if not isinstance(observation_ref, str) or _OBSERVATION_REF.fullmatch(observation_ref) is None:
        return "invalid_observation_ref"
    if not isinstance(scene_revision, str) or not scene_revision.strip():
        return "invalid_scene_revision"
    if not isinstance(frame_id, str) or not frame_id.strip():
        return "invalid_frame"
    if observation_ref != f"observation://{scene_revision}/{frame_id}":
        return "invalid_observation_binding"
    calibration_ref = arguments.get("calibration_ref")
    if not isinstance(calibration_ref, str) or not calibration_ref.strip():
        return "missing_calibration"
    for name, minimum in (("freshness_ms", 0), ("max_age_ms", 1)):
        value = arguments.get(name)
        if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
            return "invalid_freshness"
    candidate_set_ref = arguments.get("candidate_set_ref")
    if (
        not isinstance(candidate_set_ref, str)
        or _CANDIDATE_SET_REF.fullmatch(candidate_set_ref) is None
    ):
        return "invalid_candidate_set_ref"
    if candidate_set_ref != f"candidate-set://{scene_revision}/{frame_id}":
        return "invalid_candidate_set_binding"
    preparation_ref = arguments.get("preparation_ref")
    if not isinstance(preparation_ref, str) or _PREPARATION_REF.fullmatch(preparation_ref) is None:
        return "invalid_preparation_ref"
    if (
        preparation_ref.removeprefix("preparation://").split("/", 1)[0] != scene_revision
        or _ref_frame_id(preparation_ref, "preparation") != frame_id
    ):
        return "invalid_preparation_binding"
    candidate_ref = arguments.get("candidate_ref")
    if not isinstance(candidate_ref, str) or _CANDIDATE_REF.fullmatch(candidate_ref) is None:
        return "invalid_candidate_ref"
    for name in ("capability_snapshot_ref", "assignment_ref"):
        value = arguments.get(name)
        if not isinstance(value, str) or _ARTIFACT_REF.fullmatch(value) is None:
            return f"invalid_{name}"
    entity_ref = arguments.get("entity_ref")
    if not isinstance(entity_ref, str) or _ENTITY_REF.fullmatch(entity_ref) is None:
        return "invalid_entity_ref"
    candidate_entity = candidate_ref.removeprefix("candidate://").split("/", 1)[0]
    if candidate_entity != entity_ref.removeprefix("entity://"):
        return "invalid_candidate_entity_binding"
    if arguments["freshness_ms"] > arguments["max_age_ms"]:
        return "stale_observation"
    return None


def _error_message(code: str) -> str:
    return {
        "invalid_arguments": "object.acquire arguments must match the strict Action schema",
        "invalid_observation_ref": "observation_ref must use observation:// scheme",
        "invalid_observation_binding": "observation_ref must match scene_revision and frame_id",
        "invalid_scene_revision": "scene_revision must be a non-empty string",
        "invalid_frame": "frame_id must be a non-empty string",
        "missing_calibration": "calibration_ref is required",
        "invalid_freshness": "freshness_ms must be non-negative and max_age_ms positive",
        "stale_observation": "observation exceeds max_age_ms",
        "invalid_candidate_set_ref": "candidate_set_ref must use candidate-set:// scheme",
        "invalid_candidate_set_binding": "candidate_set_ref must match scene_revision and frame_id",
        "invalid_preparation_ref": "preparation_ref must use preparation:// scheme",
        "invalid_preparation_binding": "preparation_ref must match scene_revision and frame_id",
        "invalid_candidate_ref": "candidate_ref must use candidate:// scheme",
        "invalid_capability_snapshot_ref": "capability_snapshot_ref must use artifact:// scheme",
        "invalid_assignment_ref": "assignment_ref must use artifact:// scheme",
        "invalid_entity_ref": "entity_ref must use entity:// scheme",
        "invalid_candidate_entity_binding": "candidate_ref must belong to entity_ref",
    }.get(code, "object.acquire request failed contract validation")


def _validate_snapshot(snapshot: AcquireSnapshot) -> str | None:
    if not isinstance(snapshot, AcquireSnapshot):
        return "invalid_snapshot"
    if snapshot.status not in _TERMINAL_STATUSES:
        return "invalid_summary_status"
    if snapshot.capability_phase not in _CAPABILITY_PHASES:
        return "invalid_capability_phase"
    if snapshot.failure_owner not in _FAILURE_OWNERS and snapshot.failure_owner is not None:
        return "invalid_failure_owner"
    if snapshot.failure_code is not None and (
        not isinstance(snapshot.failure_code, str) or not snapshot.failure_code.strip()
    ):
        return "invalid_failure_code"
    if not isinstance(snapshot.world_change_started, bool) or not isinstance(
        snapshot.outcome_known, bool
    ):
        return "invalid_summary_boolean"
    if snapshot.status == "unknown" and snapshot.outcome_known:
        return "invalid_unknown_outcome"
    if snapshot.status == "succeeded" and (
        snapshot.failure_owner not in {None, "none"} or snapshot.failure_code is not None
    ):
        return "invalid_success_failure_fields"
    if snapshot.new_scene_revision is not None and (
        not isinstance(snapshot.new_scene_revision, str)
        or not snapshot.new_scene_revision.strip()
    ):
        return "invalid_new_scene_revision"
    if (
        snapshot.status == "succeeded"
        and snapshot.world_change_started
        and snapshot.outcome_known
        and snapshot.new_scene_revision is None
    ):
        return "missing_new_scene_revision"
    if snapshot.status != "succeeded" and snapshot.failure_owner in {None, "none"}:
        return "invalid_failure_owner"
    if snapshot.status != "succeeded" and snapshot.failure_code is None:
        return "invalid_failure_code"
    if snapshot.evidence_availability not in _EVIDENCE_AVAILABILITY:
        return "invalid_evidence_availability"
    if not isinstance(snapshot.artifact_refs, (tuple, list)):
        return "invalid_artifact_refs"
    refs = list(snapshot.artifact_refs)
    if any(not isinstance(ref, str) or _ARTIFACT_REF.fullmatch(ref) is None for ref in refs):
        return "invalid_artifact_refs"
    if len(set(refs)) != len(refs):
        return "invalid_artifact_refs"
    if snapshot.evidence_availability == "none" and refs:
        return "invalid_evidence_availability"
    if snapshot.evidence_availability in {"complete", "partial"} and not refs:
        return "invalid_evidence_availability"
    if not isinstance(snapshot.bounded_metric_names, (tuple, list)):
        return "invalid_metric_names"
    metrics = list(snapshot.bounded_metric_names)
    if len(set(metrics)) != len(metrics) or any(
        not isinstance(name, str) or _METRIC_NAME.fullmatch(name) is None for name in metrics
    ):
        return "invalid_metric_names"
    if (
        isinstance(snapshot.pending_polls, bool)
        or not isinstance(snapshot.pending_polls, int)
        or snapshot.pending_polls < 0
    ):
        return "invalid_snapshot"
    if not isinstance(snapshot.provider_available, bool):
        return "invalid_snapshot"
    if not isinstance(snapshot.retryable_in_revision, bool) or not isinstance(snapshot.requires_replan, bool):
        return "invalid_recovery_facts"
    if not isinstance(snapshot.recommended_action, str) or not snapshot.recommended_action.strip():
        return "invalid_recovery_facts"
    if not isinstance(snapshot.phase, str) or not snapshot.phase.strip():
        return "invalid_recovery_facts"
    if snapshot.selected_arm is not None and (not isinstance(snapshot.selected_arm, str) or not snapshot.selected_arm.strip()):
        return "invalid_recovery_facts"
    if snapshot.failed_phase is not None and (not isinstance(snapshot.failed_phase, str) or not snapshot.failed_phase.strip()):
        return "invalid_recovery_facts"
    if not validate_recovery_arm_attempts(snapshot.arm_attempts):
        return "invalid_recovery_facts"
    if not isinstance(snapshot.evidence_refs, (tuple, list)) or any(
        not isinstance(ref, str) or _ARTIFACT_REF.fullmatch(ref) is None
        for ref in snapshot.evidence_refs
    ):
        return "invalid_recovery_facts"
    if snapshot.possession_state not in {None, "empty", "holding"}:
        return "invalid_possession_state"
    if snapshot.object_support_state not in {None, "on_support", "displaced", "unknown"}:
        return "invalid_object_support_state"
    measurement_fields = {
        "lift_displacement_m",
        "minimum_lift_m",
        "support_clearance_m",
        "support_tolerance_m",
    }
    if snapshot.acquisition_measurement is not None:
        if (
            not isinstance(snapshot.acquisition_measurement, dict)
            or any(
                key not in measurement_fields
                or isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                for key, value in snapshot.acquisition_measurement.items()
            )
        ):
            return "invalid_acquisition_measurement"
    if snapshot.failure_code == "acquisition_postcondition_failed":
        measurement = snapshot.acquisition_measurement
        if (
            snapshot.status != "failed"
            or snapshot.outcome_known is not True
            or snapshot.world_change_started is not True
            or snapshot.failure_owner != "execution_verification"
            or snapshot.possession_state != "empty"
            or snapshot.object_support_state != "on_support"
            or not isinstance(measurement, dict)
            or set(measurement) != measurement_fields
        ):
            return "invalid_acquisition_postcondition"
        lift_displacement = float(measurement["lift_displacement_m"])
        minimum_lift = float(measurement["minimum_lift_m"])
        support_clearance = float(measurement["support_clearance_m"])
        support_tolerance = float(measurement["support_tolerance_m"])
        if (
            minimum_lift <= 0
            or support_tolerance < 0
            or lift_displacement >= minimum_lift
            or abs(support_clearance) > support_tolerance
        ):
            return "invalid_acquisition_postcondition"
    return None


def terminal_result(arguments: dict[str, Any], snapshot: AcquireSnapshot) -> dict[str, Any]:
    """Project provider facts into the bounded, redacted terminal ToolResult."""

    summary = {
        "version": CAPABILITY_OUTCOME_SUMMARY_VERSION,
        "capability_phase": snapshot.capability_phase,
        "status": snapshot.status,
        "failure_owner": snapshot.failure_owner,
        "failure_code": snapshot.failure_code,
        "world_change_started": snapshot.world_change_started,
        "outcome_known": snapshot.outcome_known,
        "evidence_availability": snapshot.evidence_availability,
        "artifact_refs": list(snapshot.artifact_refs),
        "bounded_metric_names": list(snapshot.bounded_metric_names),
        "retryable_in_revision": snapshot.retryable_in_revision,
        "requires_replan": snapshot.requires_replan,
        "recommended_action": snapshot.recommended_action,
        "phase": snapshot.phase,
        "selected_arm": snapshot.selected_arm,
        "failed_phase": snapshot.failed_phase,
        "arm_attempts": list(snapshot.arm_attempts),
        "evidence_refs": list(snapshot.evidence_refs),
    }
    if snapshot.possession_state is not None:
        summary["possession_state"] = snapshot.possession_state
    if snapshot.object_support_state is not None:
        summary["object_support_state"] = snapshot.object_support_state
    if snapshot.acquisition_measurement is not None:
        summary["acquisition_measurement"] = dict(snapshot.acquisition_measurement)
    result = {
        "status": snapshot.status,
        "observation_ref": arguments["observation_ref"],
        "scene_revision": arguments["scene_revision"],
        "frame": {"frame_id": arguments["frame_id"], "unit": "m"},
        "calibration_ref": arguments["calibration_ref"],
        "candidate_set_ref": arguments["candidate_set_ref"],
        "preparation_ref": arguments["preparation_ref"],
        "candidate_ref": arguments["candidate_ref"],
        "entity_ref": arguments["entity_ref"],
        "capability_snapshot_ref": arguments["capability_snapshot_ref"],
        "assignment_ref": arguments["assignment_ref"],
        "capability_outcome_summary": summary,
    }
    if snapshot.new_scene_revision is not None:
        result["new_scene_revision"] = snapshot.new_scene_revision
    return result


class ObjectAcquireEndpoint:
    """Validate and admit one bounded Action without owning Gateway lifecycle state."""

    def __init__(
        self,
        provider: AcquireProvider,
        *,
        readiness_gate: ActionReadinessGate | None = None,
    ) -> None:
        self.provider = provider
        self.readiness_gate = readiness_gate

    def validate(self, arguments: Any) -> dict[str, Any] | AcquireRejection:
        """Validate inputs and readiness without starting the provider."""
        error = validate_arguments(arguments)
        if error is not None:
            status_code = {
                "missing_calibration": 422,
                "stale_observation": 409,
            }.get(error, 400)
            return AcquireRejection(status_code, error, _error_message(error))
        assert isinstance(arguments, dict)
        if self.readiness_gate is not None:
            try:
                readiness_error = self.readiness_gate.check(dict(arguments))
            except Exception:
                return AcquireRejection(
                    503,
                    "readiness_gate_error",
                    "readiness evidence gate failed",
                )
            if readiness_error is not None:
                if not isinstance(readiness_error, str) or not readiness_error.strip():
                    return AcquireRejection(
                        502,
                        "invalid_readiness_gate_result",
                        "readiness evidence gate returned an invalid result",
                    )
                return AcquireRejection(
                    409,
                    readiness_error,
                    "readiness evidence is not admissible for this Action",
                )
        return dict(arguments)

    def execute(self, arguments: dict[str, Any]) -> AcquireAdmission | AcquireRejection:
        """Start the provider after the Gateway has allocated invocation identity."""
        try:
            snapshot = self.provider.acquire(dict(arguments))
        except Exception:
            return AcquireRejection(
                503,
                "acquire_provider_error",
                "object acquisition provider failed",
            )
        if snapshot is None:
            return AcquireRejection(
                503,
                "acquire_unavailable",
                "object acquisition provider is unavailable",
            )
        if not isinstance(snapshot, AcquireSnapshot):
            return AcquireRejection(
                502,
                "invalid_snapshot",
                "object acquisition provider returned an invalid snapshot",
            )
        if self.readiness_gate is not None and snapshot.world_change_started is True:
            return AcquireRejection(
                502,
                "motion_started_in_no_motion_mode",
                "no-motion Action provider reported world change",
            )
        if not snapshot.provider_available:
            return AcquireRejection(
                503,
                "acquire_unavailable",
                "object acquisition provider is unavailable",
            )
        snapshot_error = _validate_snapshot(snapshot)
        if snapshot_error is not None:
            return AcquireRejection(
                502,
                snapshot_error,
                "object acquisition result failed contract validation",
            )
        return AcquireAdmission(snapshot, terminal_result(arguments, snapshot))

    def admit(self, arguments: Any) -> AcquireAdmission | AcquireRejection:
        validated = self.validate(arguments)
        if isinstance(validated, AcquireRejection):
            return validated
        return self.execute(validated)

    def invoke(self, arguments: Any) -> AcquireAdmission | AcquireRejection:
        """Alias used by Gateway adapters that call every operation ``invoke``."""

        return self.admit(arguments)


__all__ = [
    "ACQUIRE_TOOL_ID",
    "ACQUIRE_ENDPOINT_ID",
    "ACQUIRE_OPERATION",
    "CAPABILITY_OUTCOME_SUMMARY_VERSION",
    "AcquireProvider",
    "AcquireSnapshot",
    "AcquireAdmission",
    "AcquireRejection",
    "ActionReadinessGate",
    "ACQUIRE_TOOL_SPEC",
    "ObjectAcquireEndpoint",
    "terminal_result",
    "validate_arguments",
]
