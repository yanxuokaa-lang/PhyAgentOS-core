"""Provider-neutral bounded object placement Action contract."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Protocol

from .object_acquire import (
    CAPABILITY_OUTCOME_SUMMARY_VERSION,
    _arm_attempt_schema,
    _ref_frame_id,
    validate_recovery_arm_attempts,
)

PLACE_TOOL_ID = "object.place"
PLACE_ENDPOINT_ID = "object_placement"
PLACE_OPERATION = "place"

_OBSERVATION_REF = re.compile(r"^observation://[^/]+/[^/]+$")
_CANDIDATE_SET_REF = re.compile(r"^candidate-set://[^/]+/.+$")
_PREPARATION_REF = re.compile(r"^preparation://[^/]+/.+$")
_CANDIDATE_REF = re.compile(r"^candidate://[^/]+/.+$")
_ENTITY_REF = re.compile(r"^entity://[^/]+$")
_ACQUIRE_INVOCATION_REF = re.compile(r"^invocation://object-acquire/[^/]+$")
_DESTINATION_REF = re.compile(r"^destination://[^\s]+$")
_ARTIFACT_REF = re.compile(r"^artifact://[^/]+/.+$")
_METRIC_NAME = re.compile(r"^[a-z][a-z0-9_]{0,63}$")

_CAPABILITY_PHASES = ("transport", "descent", "release", "retreat", "none")
_TERMINAL_STATUSES = ("succeeded", "failed", "cancelled", "stopped", "unknown")
_FAILURE_OWNERS = (
    "none",
    "input",
    "binding",
    "readiness",
    "planner",
    "execution",
    "evidence",
    "settlement",
    "operator",
    "infrastructure",
)
_EVIDENCE_AVAILABILITY = ("complete", "partial", "none", "unknown")


def _ref_scene_revision(reference: str, scheme: str) -> str:
    """Return the scene component carried by a provenance URI."""
    prefix = f"{scheme}://"
    return reference.removeprefix(prefix).split("/", 1)[0]

_INPUT_KEYS = {
    "observation_ref",
    "scene_revision",
    "frame_id",
    "calibration_ref",
    "freshness_ms",
    "max_age_ms",
    "candidate_set_ref",
    "preparation_ref",
    "candidate_ref",
    "entity_ref",
    "acquire_invocation_ref",
    "destination_ref",
    "capability_snapshot_ref",
    "assignment_ref",
}


class PlaceProvider(Protocol):
    """Gateway-side provider that starts one bounded placement execution."""

    def place(self, request: dict[str, Any]) -> "PlaceSnapshot | None": ...


class ActionReadinessGate(Protocol):
    """Validate immutable readiness evidence before provider admission."""

    def check(self, request: dict[str, Any]) -> str | None: ...


@dataclass(frozen=True)
class PlaceSnapshot:
    """Provider-neutral terminal facts plus an internal fake pending budget."""

    capability_phase: str = "retreat"
    status: str = "succeeded"
    failure_owner: str | None = None
    failure_code: str | None = None
    world_change_started: bool = False
    outcome_known: bool = True
    evidence_availability: str = "none"
    artifact_refs: tuple[str, ...] = field(default_factory=tuple)
    post_release_evidence_availability: str = "none"
    post_release_evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    release_confirmed: bool = False
    retreat_completed: bool = False
    clear_of_target: bool = False
    observation_ready: bool = False
    new_scene_revision: str | None = None
    bounded_metric_names: tuple[str, ...] = field(default_factory=tuple)
    retryable_in_revision: bool = False
    requires_replan: bool = False
    recommended_action: str = "continue"
    phase: str = "place"
    selected_arm: str | None = None
    failed_phase: str | None = None
    arm_attempts: tuple[dict[str, Any], ...] = field(default_factory=tuple)
    evidence_refs: tuple[str, ...] = field(default_factory=tuple)
    pending_polls: int = 0
    provider_available: bool = True


@dataclass(frozen=True)
class PlaceAdmission:
    """Validated provider plan held by the Gateway invocation owner."""

    snapshot: PlaceSnapshot
    terminal_result: dict[str, Any]


@dataclass(frozen=True)
class PlaceRejection:
    """HTTP rejection that occurs before a placement invocation is created."""

    status_code: int
    code: str
    message: str


def _evidence_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": ["availability", "artifact_refs"],
        "properties": {
            "availability": {"enum": list(_EVIDENCE_AVAILABILITY)},
            "artifact_refs": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            },
        },
    }


def _summary_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "version",
            "capability_phase",
            "status",
            "failure_owner",
            "failure_code",
            "world_change_started",
            "outcome_known",
            "evidence_availability",
            "artifact_refs",
            "post_release_evidence",
            "release_confirmed",
            "retreat_completed",
            "clear_of_target",
            "observation_ready",
            "new_scene_revision",
            "bounded_metric_names",
            "retryable_in_revision",
            "requires_replan",
            "recommended_action",
            "phase",
            "selected_arm",
            "failed_phase",
            "arm_attempts",
            "evidence_refs",
        ],
        "properties": {
            "version": {"const": CAPABILITY_OUTCOME_SUMMARY_VERSION},
            "capability_phase": {"enum": list(_CAPABILITY_PHASES)},
            "status": {"enum": list(_TERMINAL_STATUSES)},
            "failure_owner": {"enum": list(_FAILURE_OWNERS) + [None]},
            "failure_code": {"type": ["string", "null"]},
            "world_change_started": {"type": "boolean"},
            "outcome_known": {"type": "boolean"},
            "evidence_availability": {"enum": list(_EVIDENCE_AVAILABILITY)},
            "artifact_refs": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            },
            "post_release_evidence": _evidence_schema(),
            "release_confirmed": {"type": "boolean"},
            "retreat_completed": {"type": "boolean"},
            "clear_of_target": {"type": "boolean"},
            "observation_ready": {"type": "boolean"},
            "new_scene_revision": {"type": ["string", "null"]},
            "bounded_metric_names": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^[a-z][a-z0-9_]{0,63}$"},
            },
            "retryable_in_revision": {"type": "boolean"},
            "requires_replan": {"type": "boolean"},
            "recommended_action": {"type": "string", "minLength": 1},
            "phase": {"type": "string", "minLength": 1},
            "selected_arm": {"type": ["string", "null"]},
            "failed_phase": {"type": ["string", "null"]},
            "arm_attempts": {"type": "array", "items": _arm_attempt_schema()},
            "evidence_refs": {
                "type": "array",
                "items": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            },
        },
    }


def _terminal_result_schema() -> dict[str, Any]:
    return {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "status",
            "observation_ref",
            "scene_revision",
            "frame",
            "calibration_ref",
            "candidate_set_ref",
            "preparation_ref",
            "candidate_ref",
            "entity_ref",
            "acquire_invocation_ref",
            "destination_ref",
            "capability_snapshot_ref",
            "assignment_ref",
            "capability_outcome_summary",
            "release_confirmed",
            "retreat_completed",
            "clear_of_target",
            "observation_ready",
            "new_scene_revision",
        ],
        "properties": {
            "status": {"enum": list(_TERMINAL_STATUSES)},
            "observation_ref": {
                "type": "string",
                "pattern": r"^observation://[^/]+/[^/]+$",
            },
            "scene_revision": {"type": "string", "minLength": 1},
            "frame": {
                "type": "object",
                "additionalProperties": False,
                "required": ["frame_id", "unit"],
                "properties": {
                    "frame_id": {"type": "string", "minLength": 1},
                    "unit": {"const": "m"},
                },
            },
            "calibration_ref": {"type": "string", "minLength": 1},
            "candidate_set_ref": {
                "type": "string",
                "pattern": r"^candidate-set://[^/]+/.+$",
            },
            "preparation_ref": {
                "type": "string",
                "pattern": r"^preparation://[^/]+/.+$",
            },
            "candidate_ref": {"type": "string", "pattern": r"^candidate://[^/]+/.+$"},
            "entity_ref": {"type": "string", "pattern": r"^entity://[^/]+$"},
            "acquire_invocation_ref": {
                "type": "string",
                "pattern": r"^invocation://object-acquire/[^/]+$",
            },
            "destination_ref": {"type": "string", "pattern": r"^destination://[^\s]+$"},
            "capability_snapshot_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            "assignment_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            "capability_outcome_summary": _summary_schema(),
            "release_confirmed": {"type": "boolean"},
            "retreat_completed": {"type": "boolean"},
            "clear_of_target": {"type": "boolean"},
            "observation_ready": {"type": "boolean"},
            "new_scene_revision": {"type": ["string", "null"]},
        },
    }


PLACE_TOOL_SPEC: dict[str, Any] = {
    "tool_id": PLACE_TOOL_ID,
    "implementation_id": "object.placement",
    "endpoint_id": PLACE_ENDPOINT_ID,
    "operation": PLACE_OPERATION,
    "semantics": "action",
    "planning": {
        "schema_version": "paos-tool-spec-policy/v1",
        "capabilities": [PLACE_TOOL_ID],
        "scene_write_behavior": "new_revision",
        "input_binding_keys": ["entity_ref", "destination_ref"],
        "argument_projection": "completed_acquisition_action_v1",
        "argument_projection_plan": {
            "projection_id": "completed_acquisition_action_v1",
            "join_field": "entity_ref",
            "source_slots": {
                "acquisition": {
                    "tool_id": "object.acquire",
                    "source_scope": "predecessor",
                    "scene_relation": "predecessor_effect",
                    "join_field_path": ["result", "entity_ref"],
                    "source_field_map": {
                        "observation_ref": ["result", "observation_ref"],
                        "scene_revision": ["result", "new_scene_revision"],
                        "frame_id": ["result", "frame", "frame_id"],
                        "calibration_ref": ["result", "calibration_ref"],
                        "freshness_ms": ["freshness_ms"],
                        "max_age_ms": ["max_age_ms"],
                        "candidate_set_ref": ["result", "candidate_set_ref"],
                        "preparation_ref": ["result", "preparation_ref"],
                        "candidate_ref": ["result", "candidate_ref"],
                        "acquire_invocation_ref": ["invocation_id"],
                        "capability_snapshot_ref": ["result", "capability_snapshot_ref"],
                        "assignment_ref": ["result", "assignment_ref"],
                    },
                }
            },
            "top_level_fields": ["entity_ref", "destination_ref"],
        },
    },
    "description": (
        "Admit one bounded object placement workflow using a completed acquisition and a "
        "destination reference; transport, descent, release, and retreat remain internal "
        "Gateway phases."
    ),
    "input_schema": {
        "type": "object",
        "additionalProperties": False,
        "required": [
            "observation_ref",
            "scene_revision",
            "frame_id",
            "calibration_ref",
            "freshness_ms",
            "max_age_ms",
            "candidate_set_ref",
            "preparation_ref",
            "candidate_ref",
            "entity_ref",
            "acquire_invocation_ref",
            "destination_ref",
            "capability_snapshot_ref",
            "assignment_ref",
        ],
        "properties": {
            "observation_ref": {"type": "string", "pattern": r"^observation://[^/]+/[^/]+$"},
            "scene_revision": {"type": "string", "minLength": 1},
            "frame_id": {"type": "string", "minLength": 1},
            "calibration_ref": {"type": "string", "minLength": 1},
            "freshness_ms": {"type": "integer", "minimum": 0},
            "max_age_ms": {"type": "integer", "minimum": 1},
            "candidate_set_ref": {
                "type": "string",
                "pattern": r"^candidate-set://[^/]+/.+$",
            },
            "preparation_ref": {"type": "string", "pattern": r"^preparation://[^/]+/.+$"},
            "candidate_ref": {"type": "string", "pattern": r"^candidate://[^/]+/.+$"},
            "entity_ref": {"type": "string", "pattern": r"^entity://[^/]+$"},
            "acquire_invocation_ref": {
                "type": "string",
                "pattern": r"^invocation://object-acquire/[^/]+$",
            },
            "destination_ref": {"type": "string", "pattern": r"^destination://[^\s]+$"},
            "capability_snapshot_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
            "assignment_ref": {"type": "string", "pattern": r"^artifact://[^/]+/.+$"},
        },
    },
    "output_schema": {
        "type": "object",
        "additionalProperties": False,
        "required": ["invocation_id", "attempt_id", "phase"],
        "properties": {
            "invocation_id": {"type": "string", "pattern": r"^invocation://[^/]+/.+$"},
            "attempt_id": {"type": "string", "pattern": r"^attempt://[^/]+/.+$"},
            "phase": {
                "enum": [
                    "accepted",
                    "running",
                    "completed",
                    "failed",
                    "cancelled",
                    "stopped",
                    "unknown",
                ]
            },
            "cancel_requested": {"type": "boolean"},
            "result": _terminal_result_schema(),
        },
    },
    "robot_frame_profile": {
        "observation_frame": "observation",
        "unit": "m",
        "orientation_convention": "candidate-bound",
    },
    "max_concurrency": 1,
    "cancellation": "supported_via_common_cancel_route",
    "unknown_semantics": "terminal_for_accounting_not_physical_stop",
}


def validate_arguments(arguments: Any) -> str | None:
    """Validate all Action inputs before provider or invocation allocation."""

    if not isinstance(arguments, dict) or set(arguments) != _INPUT_KEYS:
        return "invalid_arguments"
    observation_ref = arguments.get("observation_ref")
    scene_revision = arguments.get("scene_revision")
    frame_id = arguments.get("frame_id")
    if not isinstance(observation_ref, str) or _OBSERVATION_REF.fullmatch(observation_ref) is None:
        return "invalid_observation_ref"
    if not isinstance(scene_revision, str) or not scene_revision.strip():
        return "invalid_scene_revision"
    if not isinstance(frame_id, str) or not frame_id.strip():
        return "invalid_frame"
    # ``scene_revision`` is the Runtime scene in which this placement is
    # admitted.  The observation/candidate/preparation references are the
    # immutable acquire provenance and may belong to the immediately preceding
    # scene after the Runtime advances while the object is being held.  They
    # must still agree with one another and retain the selected frame.
    source_scene_revision = _ref_scene_revision(observation_ref, "observation")
    if observation_ref != f"observation://{source_scene_revision}/{frame_id}":
        return "invalid_observation_binding"
    calibration_ref = arguments.get("calibration_ref")
    if not isinstance(calibration_ref, str) or not calibration_ref.strip():
        return "missing_calibration"
    for name, minimum in (("freshness_ms", 0), ("max_age_ms", 1)):
        value = arguments.get(name)
        if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
            return "invalid_freshness"
    candidate_set_ref = arguments.get("candidate_set_ref")
    if (
        not isinstance(candidate_set_ref, str)
        or _CANDIDATE_SET_REF.fullmatch(candidate_set_ref) is None
    ):
        return "invalid_candidate_set_ref"
    if candidate_set_ref != f"candidate-set://{source_scene_revision}/{frame_id}":
        return "invalid_candidate_set_binding"
    preparation_ref = arguments.get("preparation_ref")
    if not isinstance(preparation_ref, str) or _PREPARATION_REF.fullmatch(preparation_ref) is None:
        return "invalid_preparation_ref"
    if (
        preparation_ref.removeprefix("preparation://").split("/", 1)[0] != source_scene_revision
        or _ref_frame_id(preparation_ref, "preparation") != frame_id
    ):
        return "invalid_preparation_binding"
    candidate_ref = arguments.get("candidate_ref")
    if not isinstance(candidate_ref, str) or _CANDIDATE_REF.fullmatch(candidate_ref) is None:
        return "invalid_candidate_ref"
    entity_ref = arguments.get("entity_ref")
    if not isinstance(entity_ref, str) or _ENTITY_REF.fullmatch(entity_ref) is None:
        return "invalid_entity_ref"
    candidate_entity = candidate_ref.removeprefix("candidate://").split("/", 1)[0]
    if candidate_entity != entity_ref.removeprefix("entity://"):
        return "invalid_candidate_entity_binding"
    acquire_invocation_ref = arguments.get("acquire_invocation_ref")
    if (
        not isinstance(acquire_invocation_ref, str)
        or _ACQUIRE_INVOCATION_REF.fullmatch(acquire_invocation_ref) is None
    ):
        return "invalid_acquire_invocation_ref"
    destination_ref = arguments.get("destination_ref")
    if not isinstance(destination_ref, str) or _DESTINATION_REF.fullmatch(destination_ref) is None:
        return "invalid_destination_ref"
    for name in ("capability_snapshot_ref", "assignment_ref"):
        value = arguments.get(name)
        if not isinstance(value, str) or _ARTIFACT_REF.fullmatch(value) is None:
            return f"invalid_{name}"
    if arguments["freshness_ms"] > arguments["max_age_ms"]:
        return "stale_observation"
    return None


def _error_message(code: str) -> str:
    return {
        "invalid_arguments": "object.place arguments must match the strict Action schema",
        "invalid_observation_ref": "observation_ref must use observation:// scheme",
        "invalid_observation_binding": "observation_ref must match scene_revision and frame_id",
        "invalid_scene_revision": "scene_revision must be a non-empty string",
        "invalid_frame": "frame_id must be a non-empty string",
        "missing_calibration": "calibration_ref is required",
        "invalid_freshness": "freshness_ms must be non-negative and max_age_ms positive",
        "stale_observation": "observation exceeds max_age_ms",
        "invalid_candidate_set_ref": "candidate_set_ref must use candidate-set:// scheme",
        "invalid_candidate_set_binding": "candidate_set_ref must match scene_revision and frame_id",
        "invalid_preparation_ref": "preparation_ref must use preparation:// scheme",
        "invalid_preparation_binding": "preparation_ref must match scene_revision and frame_id",
        "invalid_candidate_ref": "candidate_ref must use candidate:// scheme",
        "invalid_entity_ref": "entity_ref must use entity:// scheme",
        "invalid_candidate_entity_binding": "candidate_ref must belong to entity_ref",
        "invalid_acquire_invocation_ref": (
            "acquire_invocation_ref must reference an object.acquire invocation"
        ),
        "invalid_destination_ref": "destination_ref must use destination:// scheme",
        "invalid_capability_snapshot_ref": "capability_snapshot_ref must use artifact:// scheme",
        "invalid_assignment_ref": "assignment_ref must use artifact:// scheme",
        "missing_place_postconditions": "release, retreat, clearance, and observation postconditions are incomplete",
        "missing_new_scene_revision": "successful placement must publish a new scene revision",
    }.get(code, "object.place request failed contract validation")


def _validate_artifacts(refs: Any, availability: Any, *, code: str) -> str | None:
    if availability not in _EVIDENCE_AVAILABILITY:
        return code
    if not isinstance(refs, (tuple, list)):
        return code
    values = list(refs)
    if any(not isinstance(ref, str) or _ARTIFACT_REF.fullmatch(ref) is None for ref in values):
        return code
    if len(set(values)) != len(values):
        return code
    if availability == "none" and values:
        return code
    if availability in {"complete", "partial"} and not values:
        return code
    return None


def _validate_snapshot(snapshot: PlaceSnapshot) -> str | None:
    if not isinstance(snapshot, PlaceSnapshot):
        return "invalid_snapshot"
    if snapshot.status not in _TERMINAL_STATUSES:
        return "invalid_summary_status"
    if snapshot.capability_phase not in _CAPABILITY_PHASES:
        return "invalid_capability_phase"
    if snapshot.failure_owner not in _FAILURE_OWNERS and snapshot.failure_owner is not None:
        return "invalid_failure_owner"
    if snapshot.failure_code is not None and (
        not isinstance(snapshot.failure_code, str) or not snapshot.failure_code.strip()
    ):
        return "invalid_failure_code"
    if not isinstance(snapshot.world_change_started, bool) or not isinstance(
        snapshot.outcome_known, bool
    ):
        return "invalid_summary_boolean"
    if snapshot.status == "unknown" and snapshot.outcome_known:
        return "invalid_unknown_outcome"
    if snapshot.status == "succeeded":
        if snapshot.post_release_evidence_availability != "complete":
            return "invalid_post_release_evidence"
        if not snapshot.post_release_evidence_refs:
            return "invalid_post_release_evidence"
        if not all((snapshot.release_confirmed, snapshot.retreat_completed, snapshot.clear_of_target, snapshot.observation_ready)):
            return "missing_place_postconditions"
        if not isinstance(snapshot.new_scene_revision, str) or not snapshot.new_scene_revision.strip():
            return "missing_new_scene_revision"
    if snapshot.status == "succeeded" and (
        snapshot.failure_owner not in {None, "none"} or snapshot.failure_code is not None
    ):
        return "invalid_success_failure_fields"
    if snapshot.status != "succeeded" and snapshot.failure_owner in {None, "none"}:
        return "invalid_failure_owner"
    if snapshot.status != "succeeded" and snapshot.failure_code is None:
        return "invalid_failure_code"
    if _validate_artifacts(
        snapshot.artifact_refs,
        snapshot.evidence_availability,
        code="invalid_evidence_availability",
    ):
        return "invalid_evidence_availability"
    if _validate_artifacts(
        snapshot.post_release_evidence_refs,
        snapshot.post_release_evidence_availability,
        code="invalid_post_release_evidence",
    ):
        return "invalid_post_release_evidence"
    if not isinstance(snapshot.bounded_metric_names, (tuple, list)):
        return "invalid_metric_names"
    metrics = list(snapshot.bounded_metric_names)
    if len(set(metrics)) != len(metrics) or any(
        not isinstance(name, str) or _METRIC_NAME.fullmatch(name) is None for name in metrics
    ):
        return "invalid_metric_names"
    if (
        isinstance(snapshot.pending_polls, bool)
        or not isinstance(snapshot.pending_polls, int)
        or snapshot.pending_polls < 0
    ):
        return "invalid_snapshot"
    if not isinstance(snapshot.provider_available, bool):
        return "invalid_snapshot"
    if not isinstance(snapshot.retryable_in_revision, bool) or not isinstance(snapshot.requires_replan, bool):
        return "invalid_recovery_facts"
    if not isinstance(snapshot.recommended_action, str) or not snapshot.recommended_action.strip():
        return "invalid_recovery_facts"
    if not isinstance(snapshot.phase, str) or not snapshot.phase.strip():
        return "invalid_recovery_facts"
    if snapshot.selected_arm is not None and (not isinstance(snapshot.selected_arm, str) or not snapshot.selected_arm.strip()):
        return "invalid_recovery_facts"
    if snapshot.failed_phase is not None and (not isinstance(snapshot.failed_phase, str) or not snapshot.failed_phase.strip()):
        return "invalid_recovery_facts"
    if not validate_recovery_arm_attempts(snapshot.arm_attempts):
        return "invalid_recovery_facts"
    if not isinstance(snapshot.evidence_refs, (tuple, list)) or any(
        not isinstance(ref, str) or _ARTIFACT_REF.fullmatch(ref) is None
        for ref in snapshot.evidence_refs
    ):
        return "invalid_recovery_facts"
    return None


def terminal_result(arguments: dict[str, Any], snapshot: PlaceSnapshot) -> dict[str, Any]:
    """Project provider facts into the bounded, redacted terminal ToolResult."""

    summary = {
        "version": CAPABILITY_OUTCOME_SUMMARY_VERSION,
        "capability_phase": snapshot.capability_phase,
        "status": snapshot.status,
        "failure_owner": snapshot.failure_owner,
        "failure_code": snapshot.failure_code,
        "world_change_started": snapshot.world_change_started,
        "outcome_known": snapshot.outcome_known,
        "evidence_availability": snapshot.evidence_availability,
        "artifact_refs": list(snapshot.artifact_refs),
        "post_release_evidence": {
            "availability": snapshot.post_release_evidence_availability,
            "artifact_refs": list(snapshot.post_release_evidence_refs),
        },
        "release_confirmed": snapshot.release_confirmed,
        "retreat_completed": snapshot.retreat_completed,
        "clear_of_target": snapshot.clear_of_target,
        "observation_ready": snapshot.observation_ready,
        "new_scene_revision": snapshot.new_scene_revision,
        "bounded_metric_names": list(snapshot.bounded_metric_names),
        "retryable_in_revision": snapshot.retryable_in_revision,
        "requires_replan": snapshot.requires_replan,
        "recommended_action": snapshot.recommended_action,
        "phase": snapshot.phase,
        "selected_arm": snapshot.selected_arm,
        "failed_phase": snapshot.failed_phase,
        "arm_attempts": list(snapshot.arm_attempts),
        "evidence_refs": list(snapshot.evidence_refs),
    }
    return {
        "status": snapshot.status,
        "observation_ref": arguments["observation_ref"],
        "scene_revision": arguments["scene_revision"],
        "frame": {"frame_id": arguments["frame_id"], "unit": "m"},
        "calibration_ref": arguments["calibration_ref"],
        "candidate_set_ref": arguments["candidate_set_ref"],
        "preparation_ref": arguments["preparation_ref"],
        "candidate_ref": arguments["candidate_ref"],
        "entity_ref": arguments["entity_ref"],
        "acquire_invocation_ref": arguments["acquire_invocation_ref"],
        "destination_ref": arguments["destination_ref"],
        "capability_snapshot_ref": arguments["capability_snapshot_ref"],
        "assignment_ref": arguments["assignment_ref"],
        "release_confirmed": snapshot.release_confirmed,
        "retreat_completed": snapshot.retreat_completed,
        "clear_of_target": snapshot.clear_of_target,
        "observation_ready": snapshot.observation_ready,
        "new_scene_revision": snapshot.new_scene_revision,
        "capability_outcome_summary": summary,
    }


class ObjectPlaceEndpoint:
    """Validate and admit one bounded Action without owning Gateway lifecycle state."""

    def __init__(
        self,
        provider: PlaceProvider,
        *,
        readiness_gate: ActionReadinessGate | None = None,
    ) -> None:
        self.provider = provider
        self.readiness_gate = readiness_gate

    def validate(self, arguments: Any) -> dict[str, Any] | PlaceRejection:
        """Validate inputs and readiness without starting the provider."""
        error = validate_arguments(arguments)
        if error is not None:
            status_code = {
                "missing_calibration": 422,
                "stale_observation": 409,
            }.get(error, 400)
            return PlaceRejection(status_code, error, _error_message(error))
        assert isinstance(arguments, dict)
        if self.readiness_gate is not None:
            try:
                readiness_error = self.readiness_gate.check(dict(arguments))
            except Exception:
                return PlaceRejection(
                    503,
                    "readiness_gate_error",
                    "readiness evidence gate failed",
                )
            if readiness_error is not None:
                if not isinstance(readiness_error, str) or not readiness_error.strip():
                    return PlaceRejection(
                        502,
                        "invalid_readiness_gate_result",
                        "readiness evidence gate returned an invalid result",
                    )
                return PlaceRejection(
                    409,
                    readiness_error,
                    "readiness evidence is not admissible for this Action",
                )
        return dict(arguments)

    def execute(self, arguments: dict[str, Any]) -> PlaceAdmission | PlaceRejection:
        """Start the provider after the Gateway has allocated invocation identity."""
        try:
            snapshot = self.provider.place(dict(arguments))
        except Exception:
            return PlaceRejection(
                503,
                "place_provider_error",
                "object placement provider failed",
            )
        if snapshot is None:
            return PlaceRejection(
                503,
                "place_unavailable",
                "object placement provider is unavailable",
            )
        if not isinstance(snapshot, PlaceSnapshot):
            return PlaceRejection(
                502,
                "invalid_snapshot",
                "object placement provider returned an invalid snapshot",
            )
        if self.readiness_gate is not None and snapshot.world_change_started is True:
            return PlaceRejection(
                502,
                "motion_started_in_no_motion_mode",
                "no-motion Action provider reported world change",
            )
        if not snapshot.provider_available:
            return PlaceRejection(
                503,
                "place_unavailable",
                "object placement provider is unavailable",
            )
        snapshot_error = _validate_snapshot(snapshot)
        if snapshot_error is not None:
            return PlaceRejection(
                502,
                snapshot_error,
                "object placement result failed contract validation",
            )
        return PlaceAdmission(snapshot, terminal_result(arguments, snapshot))

    def admit(self, arguments: Any) -> PlaceAdmission | PlaceRejection:
        validated = self.validate(arguments)
        if isinstance(validated, PlaceRejection):
            return validated
        return self.execute(validated)

    def invoke(self, arguments: Any) -> PlaceAdmission | PlaceRejection:
        """Alias used by Gateway adapters that call every operation ``invoke``."""

        return self.admit(arguments)


__all__ = [
    "PLACE_TOOL_ID",
    "PLACE_ENDPOINT_ID",
    "PLACE_OPERATION",
    "CAPABILITY_OUTCOME_SUMMARY_VERSION",
    "PlaceProvider",
    "PlaceSnapshot",
    "PlaceAdmission",
    "PlaceRejection",
    "ActionReadinessGate",
    "PLACE_TOOL_SPEC",
    "ObjectPlaceEndpoint",
    "terminal_result",
    "validate_arguments",
]
