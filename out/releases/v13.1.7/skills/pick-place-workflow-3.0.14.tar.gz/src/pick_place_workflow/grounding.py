"""Geometry-only Queries; task strategy remains with the caller."""

IDENTITY_KEYS = ("observation_ref", "scene_revision", "calibration_ref")


def _spec(tool_id, properties, required, description):
    return {
        "tool_id": tool_id, "endpoint_id": tool_id.replace(".", "_"),
        "operation": "resolve", "semantics": "query", "description": description,
        "input_schema": {"type": "object", "additionalProperties": False,
                         "properties": properties, "required": required},
        "output_schema": {
            "type": "object", "required": ["status", "motion_authorized"],
            "properties": {"status": {"enum": ["available", "unavailable"]},
                           "motion_authorized": {"const": False}},
        },
        "planning": {"schema_version": "paos-tool-spec-policy/v1",
                     "capabilities": [tool_id], "refreshes_scene": False,
                     "input_binding_keys": [], "scene_write_behavior": "none",
                     "requires_before_plan": tool_id == "scene.bind"},
    }


_REF = {"type": "string", "minLength": 1}
_POSE = {"type": "array", "minItems": 16, "maxItems": 16, "items": {"type": "number"}}
TASK_GOAL_TOOL_SPEC = _spec(
    "task.goal",
    {},
    [],
    "Read task-specification goals from the active Runtime. Goal facts are not "
    "sensor observations, motion approval, operation ordering, or task-success verdicts.",
)
TASK_GOAL_TOOL_SPEC["planning"]["requires_before_plan"] = True
TASK_GOAL_TOOL_SPEC["output_schema"]["properties"].update(
    {
        "schema_version": {"const": "paos-task-goals/v1"},
        "goal_source": {"enum": ["benchmark_task_definition", "observation_owned"]},
        "task_name": _REF,
        "seed": {"type": "integer"},
        "geometry_source": {"const": "benchmark_task_definition"},
        "goal_ref": {"type": "string", "pattern": "^artifact://.+"},
        "captured_at": _REF,
        "evidence_refs": {
            "type": "array",
            "items": {"type": "string", "pattern": "^artifact://.+"},
        },
        "goals": {
            "type": "array",
            "minItems": 1,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "required": [
                    "execution_entity_ref",
                    "destination_ref",
                    "frame_id",
                    "unit",
                    "world_T_object_target",
                ],
                "properties": {
                    "execution_entity_ref": _REF,
                    "destination_ref": _REF,
                    "frame_id": {"const": "world"},
                    "unit": {"const": "m"},
                    "world_T_object_target": _POSE,
                },
            },
        },
    }
)
BIND_TOOL_SPEC = _spec(
    "scene.bind",
    {**{k: _REF for k in IDENTITY_KEYS},
     "entity_refs": {"type": "array", "minItems": 1, "uniqueItems": True, "items": _REF}},
    [*IDENTITY_KEYS, "entity_refs"],
    "Resolve selected observed entities to execution objects using calibrated geometry. "
    "Returns binding_ref and world geometry; does not choose goals or authorize motion.",
)
STAGING_TOOL_SPEC = _spec(
    "manipulation.staging",
    {"binding_ref": _REF, "entity_ref": _REF},
    ["binding_ref", "entity_ref"],
    "Choose an observation-owned temporary destination on current free support space. "
    "Returns an opaque destination_ref and clearance evidence; does not authorize motion.",
)
STAGING_TOOL_SPEC["planning"]["requires_before_plan"] = True
TARGET_TOOL_SPEC = _spec(
    "manipulation.target",
    {"binding_ref": _REF, "entity_ref": _REF, "frame_id": _REF, "unit": {"const": "m"},
     "frame_T_object_target": {"type": "array", "minItems": 16, "maxItems": 16,
                               "items": {"type": "number"}}},
    ["binding_ref", "entity_ref", "frame_id", "unit", "frame_T_object_target"],
    "Resolve a caller-selected object target pose in world or the bound observation frame. "
    "Returns destination_ref and world_T_object_target. No sorting, slot selection, "
    "placement feasibility or motion authorization; use manipulation.prepare afterward.",
)

_COMMON_OUTPUT = {**{key: _REF for key in IDENTITY_KEYS}, "binding_ref": _REF,
                  "frame_id": {"const": "world"}, "unit": {"const": "m"},
                  "evidence_refs": {"type": "array", "items": _REF},
                  "error": {"type": "object", "properties": {"code": _REF, "message": _REF}}}
BIND_TOOL_SPEC["output_schema"]["properties"].update({
    **_COMMON_OUTPUT, "captured_at": _REF, "validity": {"const": "current_action_driven_scene"},
    "diagnostics": {"type": "object"},
    "observation_frame_id": _REF, "world_T_observation": _POSE,
    "entities": {"type": "array", "items": {"type": "object", "properties": {
        "entity_ref": _REF, "execution_entity_ref": _REF, "world_T_object": _POSE,
        "half_extents_m": {"type": "array", "minItems": 3, "maxItems": 3, "items": {"type": "number"}},
    }}},
})
STAGING_TOOL_SPEC["output_schema"]["properties"].update({
    **_COMMON_OUTPUT, "entity_ref": _REF, "destination_ref": _REF,
    "world_T_object_target": _POSE, "support_evidence_ref": _REF,
    "clearance_m": {"type": "number", "minimum": 0},
})
TARGET_TOOL_SPEC["output_schema"]["properties"].update({
    **_COMMON_OUTPUT, "entity_ref": _REF, "destination_ref": _REF, "world_T_object_target": _POSE,
})
