import jsonschema
import pytest
from PhyAgentOS.forge.capability_runtime import OBSERVATION_TOOL_SPEC
from PhyAgentOS.planning import project_tool_spec

from pick_place_workflow.object_acquire import ACQUIRE_TOOL_SPEC
from pick_place_workflow.object_place import PLACE_TOOL_SPEC
from pick_place_workflow.persistent_runtime import (
    PersistentActionEndpoint,
    PersistentPossession,
    _ProjectedDriver,
    _spec,
)


def arguments(place=False):
    value = {"observation_ref": "observation://scene/camera", "scene_revision": "scene", "frame_id": "camera",
             "calibration_ref": "artifact://scene/calibration", "freshness_ms": 0, "max_age_ms": 1000,
             "candidate_set_ref": "candidate-set://scene/camera", "preparation_ref": "preparation://scene/camera",
             "candidate_ref": "candidate://red/0", "entity_ref": "entity://red",
             "capability_snapshot_ref": "artifact://scene/capability", "assignment_ref": "artifact://scene/assignment"}
    if place:
        value.update(acquire_invocation_ref="invocation://object-acquire/1", destination_ref="destination://red-slot")
    return value


@pytest.mark.parametrize("phase,spec", [("acquire", ACQUIRE_TOOL_SPEC), ("place", PLACE_TOOL_SPEC)])
def test_persistent_results_conform_to_published_live_schema(phase, spec):
    class Driver:
        def poll(self):
            return {"status": "succeeded", "outcome_known": True, "world_change_started": True,
                    "new_scene_revision": "scene-2", "artifact_refs": ["artifact://scene/action"]}
    result = _ProjectedDriver(Driver(), phase, arguments(phase == "place")).poll()
    live = _spec(spec)
    jsonschema.validate(result, live["output_schema"]["properties"]["result"])
    policy = project_tool_spec(live)
    assert policy.capabilities == (spec["tool_id"],)
    assert policy.input_binding_keys == (("entity_ref", "destination_ref") if phase == "place" else ("entity_ref",))


def test_owner_from_gateway_caller_is_stable_across_revision_and_record():
    seen = []
    class Client:
        def start(self, phase, invocation, owner, resolved):
            seen.append(owner)
            return object()
    endpoint = PersistentActionEndpoint("acquire", Client(), lambda phase, request: {
        **request, "assignment": {"task_id": "task-1", "assignment_ref": request["assignment_ref"]}})
    for caller in ("paos:task-1:revision-1:record-1", "paos:task-1:revision-2:record-9"):
        admission = endpoint.admit_for_caller(arguments(), caller_id=caller)
        assert not seen or seen == ["paos:task-1"]
        admission.start("invocation", "attempt")
    assert seen == ["paos:task-1", "paos:task-1"]
    with pytest.raises(ValueError, match="caller"):
        endpoint.admit_for_caller(arguments(), caller_id="diagnostic")
    with pytest.raises(ValueError, match="this task"):
        endpoint.admit_for_caller(arguments(), caller_id="paos:other:revision:record")


def test_composition_registers_all_seven_required_tools():
    from pick_place_workflow.persistent_runtime import build_persistent_runtime

    class Providers:
        def describe(self, request):
            return None

        def understand(self, request):
            return None

        def propose(self, request):
            return None

        def prepare(self, request):
            return None

    provider = Providers()
    runtime = build_persistent_runtime(
        client=object(), understanding_provider=provider, grasp_provider=provider,
        preparation_provider=provider, capability_provider=provider,
        resolve_preparation=lambda phase, request: request,
        tool_context_provider=lambda tool_id: {"ready": False, "binding_error": "not started"},
        tool_input_defaults={
            "scene.observe": {"sensor_ref": "camera/head", "max_age_ms": 1000}
        },
    )
    tools = {tool["tool_id"]: tool for tool in runtime.list_tools()["tools"]}
    assert set(tools) == {
        "scene.observe", "scene.understand", "grasp.propose", "manipulation.capabilities",
        "manipulation.prepare", "object.acquire", "object.place",
    }
    observe_schema = tools["scene.observe"]["input_schema"]
    assert observe_schema["properties"]["sensor_ref"]["default"] == "camera/head"
    assert observe_schema["properties"]["max_age_ms"]["default"] == 1000
    assert observe_schema["required"] == ["max_age_ms"]
    assert observe_schema["oneOf"] == [
        {"required": ["sensor_ref"], "not": {"required": ["sensor_refs"]}},
        {"required": ["sensor_refs"], "not": {"required": ["sensor_ref"]}},
    ]
    for tool in runtime.list_tools()["tools"]:
        capabilities = project_tool_spec(tool).capabilities
        if tool["tool_id"] == "scene.observe":
            assert capabilities == ("scene.observe", "task.verify")
        else:
            assert capabilities == (tool["tool_id"],)
        assert "object.relocate" not in capabilities
    prepare = next(
        tool
        for tool in runtime.list_tools()["tools"]
        if tool["tool_id"] == "manipulation.prepare"
    )
    assert prepare["default_timeout_ms"] == 360_000
    prepare_policy = project_tool_spec(prepare)
    assert prepare_policy.argument_projection == "candidate_set_for_entity_v1"
    assert prepare_policy.argument_projection_plan is not None
    assert (
        prepare_policy.argument_projection_plan.source_slots["candidates"].filtered_output_field
        == "candidates"
    )
    assert all(runtime.get_context(tool["tool_id"])["ready"] is False for tool in runtime.list_tools()["tools"])


def test_projected_action_diagnostics_do_not_expose_prepared_trajectory():
    class Driver:
        def poll(self):
            return {
                "status": "failed",
                "outcome_known": True,
                "world_change_started": False,
                "failure_owner": "planner",
                "failure_code": "route_failed",
                "recommended_action": "stop",
                "arm_attempts": [{
                    "arm": "arm-a",
                    "status": "fail",
                    "failed_phase": "approach",
                    "failed_waypoint_index": 0,
                    "detail": "no route",
                    "execution_plan": {"segments": [[[1.0] * 7]]},
                    "segments": [{"end_qpos": [1.0] * 7}],
                }],
            }

    result = _ProjectedDriver(Driver(), "acquire", arguments()).poll()
    attempts = result["capability_outcome_summary"]["arm_attempts"]
    assert attempts == [{
        "arm": "arm-a",
        "status": "fail",
        "failed_phase": "approach",
        "failed_waypoint_index": 0,
        "detail": "no route",
    }]
    assert "execution_plan" not in str(result)


def test_tool_defaults_must_target_declared_input_fields():
    with pytest.raises(ValueError, match="declared input fields"):
        _spec(ACQUIRE_TOOL_SPEC, argument_defaults={"sensor_ref": "camera/head"})


def test_pick_place_runtime_can_require_synchronized_observations_without_globalizing_core_policy():
    spec = _spec(
        OBSERVATION_TOOL_SPEC,
        argument_defaults={"sensor_refs": ["camera/head", "camera/front"], "max_age_ms": 1000},
        require_synchronized_views=True,
    )
    schema = spec["input_schema"]
    assert "sensor_ref" not in schema["properties"]
    assert schema["properties"]["sensor_refs"]["minItems"] == 2
    assert schema["oneOf"] == [{"required": ["sensor_refs"]}]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate({"sensor_ref": "camera/head", "max_age_ms": 1000}, schema)
    jsonschema.validate(
        {"sensor_refs": ["camera/head", "camera/front"], "max_age_ms": 1000},
        schema,
    )


def test_unknown_place_cannot_produce_semantic_completion_evidence():
    class Driver:
        def poll(self):
            return {"status": "succeeded", "outcome_known": False, "artifact_refs": ["artifact://scene/partial"]}

    result = _ProjectedDriver(Driver(), "place", arguments(True)).poll()
    assert result["status"] == "unknown"
    assert result["evidence_refs"] == ["artifact://scene/partial"]
    assert result["capability_outcome_summary"]["post_release_evidence"]["availability"] == "none"


@pytest.mark.parametrize(
    "missing_field",
    ["release_confirmed", "retreat_completed", "clear_of_target", "observation_ready"],
)
def test_place_success_without_any_postcondition_remains_unknown(missing_field):
    class Driver:
        def poll(self):
            result = {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "new_scene_revision": "scene-2",
                "artifact_refs": ["artifact://scene-2/place"],
                "release_confirmed": True,
                "retreat_completed": True,
                "clear_of_target": True,
                "observation_ready": True,
            }
            result[missing_field] = False
            return result

    result = _ProjectedDriver(Driver(), "place", arguments(True)).poll()
    assert result["status"] == "unknown"
    assert result["capability_outcome_summary"]["failure_code"] == "missing_place_postconditions"
    assert result["capability_outcome_summary"]["outcome_known"] is False


def test_evidence_free_success_does_not_complete_relocate():
    class Driver:
        def poll(self):
            return {"status": "succeeded", "outcome_known": True, "world_change_started": True}

    result = _ProjectedDriver(Driver(), "place", arguments(True)).poll()
    assert result["status"] == "unknown"
    assert result["evidence_refs"] == []
    assert result["capability_outcome_summary"]["outcome_known"] is False
    assert result["capability_outcome_summary"]["world_change_started"] is True


def test_persistent_possession_requires_acquire_then_matching_place():
    possession = PersistentPossession()
    possession.begin("acquire", owner="paos:task", entity_ref="entity://red")
    assert possession.state == "acquiring"
    possession.settle("acquire", {"status": "succeeded", "outcome_known": True, "world_change_started": True})
    assert possession.state == "holding"
    with pytest.raises(ValueError, match="does not match"):
        possession.validate_begin("place", owner="paos:other", entity_ref="entity://red", acquire_ref=None)
    possession.acquire_invocation_ref = "invocation://object-acquire/abc"
    possession.validate_begin("place", owner="paos:task", entity_ref="entity://red", acquire_ref="invocation://object-acquire/abc")
    possession.begin("place", owner="paos:task", entity_ref="entity://red", acquire_ref="invocation://object-acquire/abc")
    assert possession.state == "placing"
    possession.settle("place", {"status": "succeeded", "outcome_known": True, "world_change_started": True})
    assert possession.state == "empty"


def test_uncertain_possession_blocks_second_acquire_and_preserves_owner():
    possession = PersistentPossession()
    possession.begin("acquire", owner="paos:task", entity_ref="entity://red")
    possession.settle("acquire", {"status": "unknown", "outcome_known": False, "world_change_started": True})
    assert possession.state == "uncertain"
    with pytest.raises(ValueError, match="not admissible"):
        possession.validate_begin("acquire", owner="paos:task", entity_ref="entity://blue")
    assert possession.owner == "paos:task"
    assert possession.entity_ref == "entity://red"


def test_cancel_or_stop_without_physical_confirmation_does_not_release():
    possession = PersistentPossession()
    possession.begin("acquire", owner="paos:task", entity_ref="entity://red")
    possession.settle("acquire", {"status": "cancelled", "outcome_known": False, "world_change_started": True})
    assert possession.state == "uncertain"


def test_place_projects_current_scene_while_retaining_acquire_provenance():
    class Driver:
        def poll(self):
            return {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "artifact_refs": ["artifact://scene-2/place"],
                "new_scene_revision": "scene-3",
            }

    source = arguments(True)
    result = _ProjectedDriver(
        Driver(), "place", source, current_scene_revision="scene-2"
    ).poll()
    assert result["scene_revision"] == "scene"
    assert result["current_scene_revision"] == "scene-2"
    assert result["candidate_ref"] == source["candidate_ref"]
    assert result["preparation_ref"] == source["preparation_ref"]
    assert result["acquire_invocation_ref"] == source["acquire_invocation_ref"]


def test_acquire_result_uses_gateway_envelope_for_invocation_identity():
    class Driver:
        def poll(self):
            return {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "artifact_refs": ["artifact://scene-2/acquire"],
                "new_scene_revision": "scene-2",
            }

    result = _ProjectedDriver(
        Driver(), "acquire", arguments(), invocation_id="invocation://object-acquire/1"
    ).poll()

    assert result["new_scene_revision"] == "scene-2"
    assert "acquire_invocation_ref" not in result


def test_acquire_world_change_without_effect_scene_remains_physically_unknown():
    class Driver:
        def poll(self):
            return {
                "status": "succeeded",
                "outcome_known": True,
                "world_change_started": True,
                "artifact_refs": ["artifact://scene-2/acquire"],
            }

    result = _ProjectedDriver(Driver(), "acquire", arguments()).poll()
    summary = result["capability_outcome_summary"]

    assert result["status"] == "unknown"
    assert "new_scene_revision" not in result
    assert summary["failure_owner"] == "execution"
    assert summary["failure_code"] == "missing_new_scene_revision"
    assert summary["world_change_started"] is True
    assert summary["outcome_known"] is False


def test_restart_reconciliation_restores_only_explicit_matching_holding():
    possession = PersistentPossession(
        state="uncertain",
        owner="paos:task",
        entity_ref="entity://red",
        acquire_invocation_ref="invocation://object-acquire/abc",
    )
    snapshot = {
        "available": True,
        "holding_state": "holding",
        "owner": "paos:task",
        "entity_ref": "entity://red",
        "acquire_invocation_ref": "invocation://object-acquire/abc",
    }
    assert possession.reconcile(snapshot) == "holding"
    mismatch = {**snapshot, "entity_ref": "entity://blue"}
    assert possession.reconcile(mismatch) == "uncertain"


def test_restart_reconciliation_empty_is_explicit_and_disconnect_never_releases():
    possession = PersistentPossession(
        state="uncertain",
        owner="paos:task",
        entity_ref="entity://red",
        acquire_invocation_ref="invocation://object-acquire/abc",
    )
    assert possession.reconcile({"available": False}) == "uncertain"
    assert possession.entity_ref == "entity://red"
    assert possession.reconcile({"available": True, "holding_state": "empty"}) == "empty"
    assert possession.entity_ref is None
